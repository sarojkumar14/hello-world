/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  var role = sequelize.define('SMSRole', {
    RoleId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    RoleName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedOn: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '(getdate())'
    },
    Createdby: {
      type: DataTypes.STRING,
      allowNull: false
    },
    UpdatedOn: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: '(getdate())'
    },
    UpdatedBy: {
      type: DataTypes.STRING,
      allowNull: true
    },
  }, {timestamps: false,
      tableName: 'SMSRole'
    });

  return role;
};
