/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('SMSLanguage', {
        LanguageId: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        LanguageName: {
            type: DataTypes.STRING,
            allowNull: false
        },
        Description: {
            type: DataTypes.STRING,
            allowNull: true
        },
        IsActive: {
            type: DataTypes.BOOLEAN,
            allowNull: false
        },
        CreatedOn: {
            type: DataTypes.STRING,
            allowNull: false
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UpdatedOn: {
            type: DataTypes.STRING,
            allowNull: true
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        }
    }, {
            timestamps: false,
            tableName: 'SMSLanguage'
        });
};
