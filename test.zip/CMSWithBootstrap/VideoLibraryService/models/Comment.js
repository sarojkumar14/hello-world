/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Comment', {
    CommentId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    UserId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    VideoId: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    ResourceId: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    RepliedCommentID: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    Comments: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CreatedOn: {
      type: DataTypes.DATE,
      allowNull: false
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    UpdatedOn: {
      type: DataTypes.DATE,
      allowNull: true
    },
    UpdatedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
      timestamps: false,
      tableName: 'Comment'
    });
};
