/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('UserTag', {
    Id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    UserId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    VideoId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    ResourceId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    LibraryId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    Tags: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    CreatedDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    ModifiedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    ModifiedDate: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
      tableName: 'UserTag'
    });
};
