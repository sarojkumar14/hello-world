/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('WatchHistory', {
    WatchId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    UserId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    IsRemoved: {
      type: DataTypes.BOOLEAN,
      allowNull: false
    },
    VideoId: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    WatchedOn: {
      type: DataTypes.DATE,
      allowNull: false
    },
    CreatedOn: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
      timestamps: false,
      tableName: 'WatchHistory'
    });
};
