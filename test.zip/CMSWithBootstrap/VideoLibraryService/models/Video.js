/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Video', {
    VideoId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    Guid: {
      type: DataTypes.STRING,
      allowNull: false
    },
    FileName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    SavedFileName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    Description: {
      type: DataTypes.STRING,
      allowNull: true
    },
    EmbededURL: {
      type: DataTypes.STRING,
      allowNull: true
    },
    StandaloneURL: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ViewCount: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    Type: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Path: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Size: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    Tags: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Rating: {
      type: DataTypes.DECIMAL(18, 8),
      allowNull: true
    },
    Privacy: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Owner: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Topic: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Grade: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Unit: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CreatedOn: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    UpdatedOn: {
      type: DataTypes.STRING,
      allowNull: true
    },
    UpdatedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
      timestamps: false,
      tableName: 'Video'
    });
};
