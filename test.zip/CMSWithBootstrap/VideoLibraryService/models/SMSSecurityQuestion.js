/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  var SMSSecurityQuestion = sequelize.define('SMSSecurityQuestion', {
    SecurityQuestionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    SecurityQuestion: {
      type: DataTypes.STRING,
      allowNull: false
    },
    IsActive: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedOn: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '(getdate())'
    },
    CreatedBy: {
      type: DataTypes.DATE,
      allowNull: false,
    }
  }, {
      timestamps: false,
      tableName: 'SMSSecurityQuestion'
    });

  return SMSSecurityQuestion;
};
