/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('ConfigurationSettings', {
        ConfigId: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        ConfigKey: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ConfigValue: {
            type: DataTypes.STRING,
            allowNull: true
        },
        CreatedOn: {
            type: DataTypes.STRING,
            allowNull: false
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UpdatedOn: {
            type: DataTypes.STRING,
            allowNull: true
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        }
    }, {
            timestamps: false,
            tableName: 'ConfigurationSettings'
        });
};