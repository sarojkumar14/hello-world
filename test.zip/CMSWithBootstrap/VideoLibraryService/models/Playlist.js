/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Playlist', {
        PlaylistId: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        Title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        Description: {
            type: DataTypes.STRING,
            allowNull: true
        },
        UserId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        CreatedOn: {
            type: DataTypes.STRING,
            allowNull: false
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UpdatedOn: {
            type: DataTypes.STRING,
            allowNull: true
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        IsRemoved: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
    }, {
        timestamps: false,
        tableName: 'Playlist'
    });
};