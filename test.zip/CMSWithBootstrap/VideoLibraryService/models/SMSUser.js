/* jshint indent: 2 */
const bcrypt = require("bcrypt");

module.exports = function (sequelize, DataTypes) {
  var SMSUser = sequelize.define('SMSUser', {
    UserId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    UserName: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    FirstName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    MiddleName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    LastName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    EmailId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    Password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    RoleId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'SMSRole',
        key: 'RoleId'
      }
    },
    SecurityQuestionId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    SecurityAnswer: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedOn: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: sequelize.NOW
    },
    CreatedBy: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    UpdatedOn: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: sequelize.NOW
    },
    UpdatedBy: {
      type: DataTypes.INTEGER,
      allowNull: true
    }
  }, {
      timestamps: false,
      tableName: 'SMSUser'
    });
  SMSUser.associate = function (models) {
    models.SMSUser.belongsTo(models.SMSRole, {
      foreignKey: { name: "RoleId", allowNull: false }
    });
  }

  SMSUser.beforeCreate((user, options) => {

    return bcrypt.hash(user.Password, 10)
      .then(hash => {
        user.Password = hash;
      })
      .catch(err => {
        throw new Error();
      });
  });

  return SMSUser;
};
