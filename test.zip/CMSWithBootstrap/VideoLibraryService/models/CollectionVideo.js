/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('CollectionVideo', {
        Id: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        CollectionId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        VideoId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        CreatedOn: {
            type: DataTypes.STRING,
            allowNull: false
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UpdatedOn: {
            type: DataTypes.STRING,
            allowNull: true
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        }
    }, {
            timestamps: false,
            tableName: 'CollectionVideo'
        });
};
