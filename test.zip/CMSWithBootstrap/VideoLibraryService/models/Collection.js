/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Collection', {
        CollectionId: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        CollectionName: {
            type: DataTypes.STRING,
            allowNull: false
        },
        Description: {
            type: DataTypes.STRING,
            allowNull: true
        },
        CreatedOn: {
            type: DataTypes.STRING,
            allowNull: true
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        UpdatedOn: {
            type: DataTypes.STRING,
            allowNull: false
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        }
    }, {
            timestamps: false,
            tableName: 'Collection'
        });
};
