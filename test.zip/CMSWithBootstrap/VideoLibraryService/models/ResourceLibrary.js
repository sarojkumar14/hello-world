/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('ResourceLibrary', {
    Id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    Name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    Description: {
      type: DataTypes.STRING,
      allowNull: true
    },
    ImageUrl: {
      type: DataTypes.STRING,
      allowNull: true
    },
    CreatedDate: {
      type: DataTypes.DATE,
      allowNull: false
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    ModifiedDate: {
      type: DataTypes.DATE,
      allowNull: true
    },
    ModifiedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
      tableName: 'ResourceLibrary'
    });
};
