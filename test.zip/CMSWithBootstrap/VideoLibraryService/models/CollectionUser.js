/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('CollectionUser', {
        Id: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        CollectionId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UserId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        CreatedOn: {
            type: DataTypes.DATE,
            allowNull: false
        },
        CreatedBy: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        UpdatedOn: {
            type: DataTypes.DATE,
            allowNull: true
        },
        UpdatedBy: {
            type: DataTypes.BIGINT,
            allowNull: true
        }
    }, {
        timestamps: false,
        tableName: 'CollectionUser'
    });
};