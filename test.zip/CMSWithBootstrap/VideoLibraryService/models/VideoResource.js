/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('VideoResource', {
        Id: {
            type: DataTypes.BIGINT,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        VideoId: {
            type: DataTypes.BIGINT,
            allowNull: false
        },
        DocumentId: {
            type: DataTypes.BIGINT,
            allowNull: false
        }
    }, {
            timestamps: false,
            tableName: 'VideoDocument'
        });
};
