/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Resource', {
    DocumentId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    Guid: {
      type: DataTypes.STRING,
      allowNull: true
    },
    FileName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    SavedFileName: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Title: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Description: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Type: {
      type: DataTypes.STRING,
      allowNull: false
    },
    Path: {
      type: DataTypes.STRING,
      allowNull: false
    },
    Size: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    Tags: {
      type: DataTypes.STRING,
      allowNull: true
    },
    Ratings: {
      type: DataTypes.FLOAT,
      allowNull: true
    },
    CreatedOn: {
      type: DataTypes.STRING,
      allowNull: false
    },
    CreatedBy: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    UpdatedOn: {
      type: DataTypes.STRING,
      allowNull: true
    },
    UpdatedBy: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
      timestamps: false,
      tableName: 'Document'
    });
};
