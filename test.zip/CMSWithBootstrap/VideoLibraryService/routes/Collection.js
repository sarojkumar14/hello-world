const express = require('express');
const router = express.Router();
const collectionQuery = require('../data/Collection.data');

router.post('/createcollection', function (req, res) {

    let data = req.body;
    console.log(data)
    let title = data.CollectionName;
    let description = data.Description;

    if (title == undefined || description == undefined) {
        res.status(500).send({
            error: 'Something failed'
        });
    }
    collectionQuery.createcollection(data, function (err, result) {
        if (err || result == null) {
            res.status(500).json({
                error: 'Something failed!'
            });
        } else {
            res.json(result);
        }
    });
});


router.get('/getcollectionbyuserrole/:RoleId/:UserId', function (req, res) {
    let data = req.params;
    collectionQuery.getCollectionByUserRole(data, function (err, result) {
        if (!err) {
            res.status(200).json({
                success: true,
                data: result
            });
        } else {
            res.status(500).json({
                success: false,
                data: "No collections list found!!"
            })
        }
    });
})

router.put('/removecollection', function (req, res) {
    let data = req.body;
    collectionQuery.removecollection(data.CollectionId, function (err, result) {
        if (result == 1) {
            res.send({
                success: true,
                data: "Deleted successfully!!"
            })
        } else {
            res.status(500).send({
                success: false,
                data: "Undeleted successfully!!"
            })
        }
    });
});

router.patch('/updatecollection', function (req, res) {

    let data = req.body;
    console.log(data)
    let title = data.CollectionName;
    let description = data.Description;
    if (title == undefined || description == undefined) {
        res.status(500).send({
            error: 'Something failed'
        });
    }
    collectionQuery.updatecollection(data, function (err, result) {
        if (err || result == null) {
            res.status(500).json({
                error: 'Something failed!'
            });
        } else {
            res.json(result);
        }
    });
});

router.get('/getUserCollections', function (req, res, next) {
    collectionQuery.getUserCollections(function (err, response) {
        if (err) {
            return res.status('500').send({
                IsSuccess: false,
                Message: "Error occured while getting user collections.",
                Data: null
            })
        } else {
            return res.send({
                IsSuccess: true,
                Message: "User Collections retrived successfully.",
                Data: response.rows
            })
        }
    })
});

router.get('/getusercollectionvideos/:RoleId/:UserId/:CollectionId', function (req, res) {
    let data = req.params;
    collectionQuery.getUserCollectionVideos(data, function (err, result) {
        console.log(result);
        if (!err) {
            res.status(200).json({
                success: true,
                data: result
            })
        } else {
            res.status(500).json({
                success: false,
                data: "No collections video list found!!"
            })
        }
    });
});

router.post("/readvideotranscript", function (req, res) {
    collectionQuery.readVideoTranscript(req.body, function (err, response) {
        if (err) {
            return res.status('500').send({
                success: false,
                message: "Error occured while getting user collections.",
                data: null
            })
        } else {
            return res.send({
                success: true,
                message: "User Collections retrived successfully.",
                data: response
            })
        }
    })
})

router.get("/getallvideos/:RoleId", function (req, res) {
    let params = req.params;
    // if (params.RoleId != 1) {
    //     return res.status('500').send({
    //         success: false,
    //         message: "Admin role not mapped",
    //         data: null
    //     })
    // }
    collectionQuery.getAllVideos(function (err, response) {
        if (err) {
            return res.status('500').send({
                success: false,
                message: "Error occured while getting user collections.",
                data: null
            })
        } else {
            return res.status('200').send({
                success: true,
                message: "Success",
                data: response
            })
        }
    })
})

router.post("/adminselectvideotocollection", (req, res) => {
    let data = req.body;
    collectionQuery.adminSelectVideoToCollection(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: "User role not mapped",
                data: null
            })
        } else {
            res.status(200).json({
                success: true,
                message: "Success",
                data: result
            })
        }
    })
})

router.get("/getallusers/:RoleId", function (req, res) {
    let params = req.params;
    if (params.RoleId != 1) {
        return res.status('500').send({
            success: false,
            message: "Admin role not mapped",
            data: null
        })
    }
    collectionQuery.getAllUsers(function (err, response) {
        if (err) {
            return res.status('500').send({
                success: false,
                message: "Error occured while getting users.",
                data: null
            })
        } else {
            return res.status('200').send({
                success: true,
                message: "Success",
                data: response
            })
        }
    })
})

router.post("/adminlinkcollectiontouser", (req, res) => {
    let data = req.body;
    collectionQuery.adminLinkCollectionToUser(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: "User role not mapped",
                data: null
            })
        } else {
            res.status(200).json({
                success: true,
                message: "Success",
                data: result
            })
        }
    })
});


router.post("/getcollectioncount", (req, res) => {
    let data = req.body;
    collectionQuery.getCollectionCount(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: "User role not mapped",
                data: null
            })
        } else {
            res.status(200).json({
                success: true,
                message: "Success",
                data: result
            })
        }
    })
})

module.exports = router;