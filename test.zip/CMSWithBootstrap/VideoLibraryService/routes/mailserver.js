const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
const mailConfig = require('../global/mailConfig');

const transport = nodemailer.createTransport({
    host: mailConfig.host,
    secure: mailConfig.secure,
    port: mailConfig.port,
    auth: {
        user: mailConfig.username,
        pass: mailConfig.password
    }
});

router.post("/sendmail", function (req, res, next) {
    let data = req.body.data;

    let mailOptions = {
        from: data.mailFrom,
        to: data.mailTo,
        subject: data.mailSubject,
    };

    if (data.isPlainMail) {
        mailOptions.text = data.mailText;
    } else {
        mailOptions.html = data.mailHtml;
    }

    if (data.isHavingAttachement) {
        mailOption.attachments = data.mailAttachments;
    }

    transport.sendMail(mailOption, function (err, info) {
        if (err) {
            return res.status('500').send({
                IsSuccess: false
                , Message: `Error occured while sending mail error: ${err}`
                , Data: null
            })
        };
        return res.send({
            IsSuccess: true
            , Message: "Mail send successfully."
            , Data: info
        })

    })
});

module.exports = router;