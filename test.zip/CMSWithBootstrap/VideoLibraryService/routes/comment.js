const router = require('express').Router();
const commentQuery = require('../Data/comment.data');

router.post('/createComment', function (req, res, next) {
    let comment = req.body.data;
    commentQuery.createComment(comment, function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false,
                Message: "Error occured in added comment.",
                Data: null,
                Error: err
            });
        } else {
            return res.status(200).send({
                IsSuccess: true,
                Message: "comment added successfully.",
                Data: response,
                Error: null
            });
        }
    })
});

router.post('/updateComment', function (req, res, next) {
    let comment = req.body.data;
    commentQuery.updateComment(comment, function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false,
                Message: "Error occured in added comment.",
                Data: null,
                Error: err
            });
        } else {
            return res.status(200).send({
                IsSuccess: true,
                Message: "comment added successfully.",
                Data: response,
                Error: null
            });
        }
    })
});

router.post('/deleteComment', function (req, res, next) {
    let commentId = req.body.data;
    commentQuery.deleteComment(commentId, function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false,
                Message: "Error occured while deleting comment.",
                Data: null,
                Error: err
            });
        } else {
            return res.status(200).send({
                IsSuccess: true,
                Message: "comment deleted successfully.",
                Data: response,
                Error: null
            });
        }
    })
})

router.post('/getVideoComments', function (req, res, next) {
    let videoId = req.body.data;
    commentQuery.getCommentsByVideo(videoId, function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false,
                Message: "Error occured while retreiving comments.",
                Data: null,
                Error: err
            });
        } else {
            let length = response.length;
            if (length > 0) {
                let currentIteration = 0;
                response.forEach(element => {
                    element.ReplyComments;
                    commentQuery.getReplyOnComments(element.CommentId, function (err, replyRes) {
                        if (err) {
                            return;
                        } else {
                            if (replyRes.length > 0) {
                                element.ReplyComments = replyRes;
                            } else {
                                element.ReplyComments = null;
                            }
                        }

                        currentIteration++;
                        if (currentIteration == length) {
                            return res.status(200).send({
                                IsSuccess: true,
                                Message: "comments retrived successfully.",
                                Data: response,
                                Error: null
                            });
                        }
                    })
                });
            } else {
                return res.status(200).send({
                    IsSuccess: true,
                    Message: "No comments loaded for this video.",
                    Data: response,
                    Error: null
                });
            }
        }
    })
})

module.exports = router;