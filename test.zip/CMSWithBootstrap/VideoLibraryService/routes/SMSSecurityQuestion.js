const express = require('express');
const router = express.Router();
const fs = require('fs');
const smsSecurityQuestionQuery = require('../Data/SMSSecurityQuestion.data')

router.get('/getAllSMSSecurityQuestion', function (req, res, next) {
    smsSecurityQuestionQuery.getAllSMSSecurityQuestion(function (err, response) {
        if (err) {
          return res.status('500').send({ IsSuccess: false, Message: "Error occured while getting Security Questions.", Data: null })
        }
        else  {
            return res.send({ IsSuccess: true, Message: "Security Questions retrived successfully.", Data: response.rows })
        }
    })
})

module.exports = router;