const express = require('express');
const router = express.Router();
const elasticService = require('../Data/elastic.data');

let handlerError = function (res, err) {
    return res.status('500').json({
        success: false,
        message: 'Error occures',
        error: {
            message: err.message,
            stackTrace: err.stack
        }
    });
}

router.get('/ping', function (req, res, ) {
    elasticService.pingHost(function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.get('/health', function (req, res) {
    elasticService.checkClusterHealth(function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.post('/isIndexExist', function (req, res) {
    let indexName = req.param('indexName');
    elasticService.indexExists(indexName, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.post('/createIndex', function (req, res) {
    let indexName = req.param('indexName');
    elasticService.createIndex(indexName, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.delete('/deleteIndex', function (req, res) {
    let indexName = req.param('indexName');
    elasticService.deleteIndex(indexName, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.post('/addDocument', function (req, res) {
    let body = req.body.data;
    let payload = body.payload;
    let index = body.index;
    let _id = body._id;
    let docType = body.docType;
    if (!body.isHavingAttachement) {
        elasticService.addDocument(index, _id, docType, payload, function (err, data) {
            if (err) {
                return handlerError(res, err);
            }
            return res.status('200').json(data);
        })
    } else {
        elasticService.addDocumentWithAttachment(index, _id, docType, payload, function (err, data) {
            if (err) {
                return handlerError(res, err);
            }
            return res.status('200').json(data);
        })
    }

});

router.put('/updateDocument', function (req, res) {
    let body = req.body;
    let payload = body.payload;
    let index = body.index;
    let _id = body._id;
    let docType = body.docType;

    elasticService.updateDocument(index, _id, docType, payload, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.post('/deleteDocument', function (req, res) {
    let index = req.param('index');
    let _id = req.param('_id');
    let docType = req.param('docType');

    elasticService.deleteDocument(index, _id, docType, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data);
    })
});

router.post('/search', function (req, res) {
    let body = req.body.data;
    let payload = body.payload;
    let index = body.index;
    let docType = body.docType;

    elasticService.search(index, docType, payload, function (err, data) {
        if (err) {
            return handlerError(res, err);
        }
        return res.status('200').json(data.hits.hits);
    })
});

module.exports = router;