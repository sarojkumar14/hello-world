const router = require('express').Router();
const watchHistoryQuery = require('../Data/history.data');

router.post('/create', function (req, res, next) {
    let watch = req.body.data;
    watchHistoryQuery.createHistory(watch, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in added history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history added successfully."
                , Data: response
                , Error: null
            });
        }
    })
})

router.get('/watchedHistoryByUser', function (req, res, next) {
    let userId = req.param('userId');
    watchHistoryQuery.getWatchedHistoryByUser(userId, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in getting history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history retrieved successfully."
                , Data: response
                , Error: null
            });
        }
    })
});

router.get('/removeHistory', function (req, res, next) {
    let watchId = req.param('watchId');
    watchHistoryQuery.removeHistory(watchId, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in removing history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history removed successfully."
                , Data: response
                , Error: null
            });
        }
    })
})


module.exports = router;