const router = require('express').Router();
const configQuery = require("../Data/configSettings.data");

router.get('/getConfigSettings', function (req, res, next) {
    configQuery.getConfigSettings(function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false
                , Message: "Error occured while retreiving settings."
                , Data: null
                , Error: err
            });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Query excuted successfully."
                , Data: response
                , Error: null
            });
        }
    })
});

router.post('/upsert', function (req, res, next) {
    let body = req.body.data;
    configQuery.upsert(body, function (err, response) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false
                , Message: "Error occured while adding settings."
                , Data: null
                , Error: err
            });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Query excuted successfully."
                , Data: response
                , Error: null
            });
        }
    })
})

module.exports = router;