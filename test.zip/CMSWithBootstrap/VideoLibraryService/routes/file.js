const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const fileQuery = require('../Data/file.data');
const collectionVideoQuery = require('../Data/CollectionVideo.data');
const resourceQuery = require('../Data/Resource.data');
const videoResourceQuery = require('../Data/VideoResource.data');
const guid = require('guid');
const async = require('async');
const elastic = require('../global/elasticConfig');
const elasticService = require('../Data/elastic.data');
const languageQuery = require('../Data/SMSLanguage.data.js');

//Check fild dir is exist, If not it'll create dir
var publicDirectory = path.join(__dirname, '/../public');
fs.existsSync(publicDirectory) || fs.mkdirSync(publicDirectory);
var videoDirectory = path.join(__dirname, '/../public/video');
fs.existsSync(videoDirectory) || fs.mkdirSync(videoDirectory);
var transcriptDirectory = path.join(__dirname, '/../public/transcript')
fs.existsSync(transcriptDirectory) || fs.mkdirSync(transcriptDirectory);

router.get("/getLanguages", function (req, res) {
    languageQuery.getLanguages(function (err, response) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while fetching languages from server. Please try after some time.", Data: null, Error: err });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Languages fetched successfully."
                , Data: response.rows
                , Error: null
            });
        }
    })
});

router.post('/UploadVideo', function (req, res, next) {
    var video = req.body.video;
    video.Guid = guid.create().toString();

    var transcript = req.body.transcript;
    transcript.Guid = guid.create().toString();

    async.waterfall([
        function (callback) {
            if (video.FileData != undefined && video.FileData != null) {

                var videoGuidFileName = video.Guid + '.' + video.FileName.split('.').pop();

                var videoPath = __dirname + '/../public/video/' + videoGuidFileName;

                fs.writeFile(videoPath, video.FileData, 'base64', (err) => {
                    // throws an error, you could also catch it here
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured in File uploading.", Data: null, Error: err }, null)
                    } else {
                        return callback(null, 'one');
                    }
                });
            }
            else {
                return callback(null, 'one');
            }
        },
        function (arg1, callback) {
            video.Path = '/../public/video/';
            video.SavedFileName = video.Guid + '_' + video.FileName;
            fileQuery.UploadVideo(video, function (err, videoresponse) {
                if (err) {
                    return callback({ IsSuccess: false, Message: "Error occured while File uploading in database.", Data: null, Error: err }, null)
                }
                else {
                    elasticService.addDocument(elastic.config.Index, videoresponse.Guid, elastic.config.Type, videoresponse, function (err, data) {
                        if (err) {
                            return callback(err, null);
                        }
                        return callback(null, videoresponse);
                    })
                }
            })
        },
        function (videores, callback) {
            if (transcript.FileData != undefined && transcript.FileData != null) {
                var transcriptGuidFileName = transcript.Guid + '.' + transcript.FileName.split('.').pop();
                var transcriptPath = __dirname + '/../public/transcript/' + transcriptGuidFileName;
                fs.writeFile(transcriptPath, transcript.FileData, 'base64', (err) => {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured in transcript File uploading.", Data: null, Error: err }, null)
                    }
                    else {
                        return callback(null, videores);
                    }
                });
            }
            else {
                return callback(null, videores);
            }
        },
        function (videores, callback) {
            if (transcript.FileData != undefined && transcript.FileData != null) {
                transcript.Path = '/../public/transcript/';
                transcript.SavedFileName = transcript.Guid + '_' + transcript.FileName;
                transcript.VideoId = videores.VideoId;
                transcript.Title = "Manually Added";
                transcript.Language = "English";
                fileQuery.UploadTranscript(transcript, function (err, response) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured in transcript File uploading in database.", Data: null, Error: err }, null)
                    }
                    else {
                        return callback(null, videores);
                    }
                });
            }
            else {
                return callback(null, videores);
            }
        },
        function (videores, callback) {
            if (video.selectedCollections.length > 0 && (video.selectedCollections != undefined || video.selectedCollections != null)) {
                let selectedCollectionsLength = video.selectedCollections.length;
                let selectedCollectionIteration = 0;
                video.selectedCollections.forEach(collectionVideoElement => {
                    var collectionVideo = {
                        CollectionId: collectionVideoElement.id,
                        VideoId: videores.VideoId,
                        CreatedBy: 1,
                        CreatedOn: video.CreatedOn
                    };
                    collectionVideoQuery.CreateCollectionVideo(collectionVideo, function (err, collectionVideoResponse) {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Error occured while creating Collection Video in database.", Data: null, Error: err }, null)
                        }
                        selectedCollectionIteration++;
                        if (selectedCollectionIteration == selectedCollectionsLength) {
                            return callback(null, videores);
                        }
                    });
                })
            } else {
                return callback(null, videores);
            }
        },
        function (arg1, callback) {
            var resources = req.body.resources;
            if ((resources.ResourcesFiles != "undefined" || resources.ResourcesFiles != null) && resources.ResourcesFiles.length > 0) {
                var resourceDirectory = path.join(__dirname, '/../public/resource');
                fs.existsSync(resourceDirectory) || fs.mkdirSync(resourceDirectory);
                let length = resources.ResourcesFiles.length;
                let currentIteration = 0;
                resources.ResourcesFiles.forEach(element => {

                    var resource = {
                        Guid: guid.create().toString(),
                        FileName: element.FileName,
                        Title: null, Description: null,
                        Type: element.FileType,
                        Path: '/../public/resource/',
                        Size: element.Size,
                        Tags: null,
                        Ratings: null,
                        CreatedOn: new Date(Date.now()).toISOString(),
                        CreatedBy: 1
                    };
                    resource.SavedFileName = resource.Guid + '_' + resource.FileName;
                    var resourceGuidFileName = resource.Guid + '.' + element.FileName.split('.').pop();
                    var resourcePath = __dirname + '/../public/resource/' + resourceGuidFileName;
                    async.waterfall([
                        function (innercallback) {
                            resourceQuery.CreateResource(resource, function (err, response) {
                                if (err) {
                                    return innercallback(err)
                                }
                                else {
                                    response.dataValues.data = element.FileData;
                                    elasticService.addDocumentWithAttachment(elastic.config.Index, response.dataValues.Guid, elastic.config.Type, response.dataValues,
                                        function (err, data) {
                                            if (err) {
                                                return innercallback(err, null);
                                            }
                                            return innercallback(null, response);
                                        })
                                }
                            });
                        },
                        function (resourceResponse, callback) {
                            var videoResource = {
                                VideoId: arg1.VideoId,
                                DocumentId: resourceResponse.DocumentId
                            };

                            videoResourceQuery.CreateVideoResource(videoResource, function (err, videoResourceRes) {
                                if (err) {
                                    return callback({ IsSuccess: false, Message: "Error occured while creating Video Resource in database.", Data: null, Error: err }, null)
                                }
                                else {
                                    return callback(null, videoResourceRes);
                                }
                            });
                        },
                        function (response, innercallback) {
                            fs.writeFile(resourcePath, element.FileData, 'base64', (err) => {
                                // throws an error, you could also catch it here
                                if (err) {
                                    return innercallback(err)
                                }
                                currentIteration++;
                                if (currentIteration == length) {
                                    return innercallback(null, 'done');
                                }
                            });
                        }
                    ], function (err, result) {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Error occured in Resource File uploading.", Data: null, Error: err })
                        } else {
                            return callback(null, 'done');
                        }
                    });
                })
            } else {
                return callback(null, 'done');
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: err.message, Data: null, Error: err })
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Video uploaded successfully."
                , Data: {}
                , Error: null
            });
        }
    });
});

router.get('/updateViewCount', function (req, res, next) {
    let videoId = req.param('videoId');

    fileQuery.updateViewCount(videoId, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in update view count."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "View count updated successfully."
                , Data: response
                , Error: null
            });
        }
    })
});

router.get('/getVideoById', function (req, res, next) {
    let guid = req.param('guid');
    let responseData = { videoFileData: null, transcriptFileData: null, resourcesFileData: null };

    async.waterfall([
        function (callback) {
            if (guid != undefined && guid != null) {
                fileQuery.getVideoById(guid, function (err, videoResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while fetching video Information.", Data: null, Error: err }, null);
                    }
                    else {
                        responseData.video = videoResponse;
                        return callback(null, responseData, videoResponse.VideoId);
                    }
                })
            }
            else {
                return callback({ IsSuccess: false, Message: "Guid not available.", Data: null, Error: err }, null);
            }
        },
        function (responseData, videoId, callback) {
            var videoGuidFileName = guid + '.' + responseData.video.FileName.split('.').pop();
            var videoPath = __dirname + '/../public/video/' + videoGuidFileName;

            fs.readFile(videoPath, 'base64', (err, videoFileData) => {
                if (err) {
                    //costume error message
                    if (err.code == "ENOENT") {
                        return callback({ IsSuccess: false, Message: "Video file not available.", Data: null, Error: err }, null);
                    }
                    else {
                        return callback({ IsSuccess: false, Message: "Error occured while reading video file in path.", Data: null, Error: err }, null);
                    }
                } else {
                    responseData.videoFileData = videoFileData;
                    return callback(null, videoId);
                }
            });
        },
        function (videoId, callback) {
            if (videoId != undefined && videoId != null) {
                fileQuery.getTranscriptByVideoId(videoId, function (err, transcriptResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while fetching transcript Information", Data: null, Error: err }, null)
                    }
                    else {
                        responseData.transcript = transcriptResponse;
                        if (responseData.transcript) {
                            return callback(null, responseData, transcriptResponse.Guid, transcriptResponse.FileName);
                        }
                        else {
                            responseData.transcript = null;
                            return callback(null, responseData, null, null);
                        }
                    }
                });
            }
            else {
                return callback({ IsSuccess: false, Message: "Video Id not available.", Data: null, Error: err }, null)
            }
        },
        function (responseData, Guid, FileName, callback) {
            if ((Guid != undefined && Guid != null) || (FileName != undefined && FileName != null)) {
                var transcriptGuidFileName = Guid + '.' + FileName.split('.').pop();
                var transcriptPath = __dirname + '/../public/transcript/' + transcriptGuidFileName;
                fs.readFile(transcriptPath, 'base64', (err, transcriptFileData) => {
                    if (err) {
                        //costume error message
                        if (err.code == "ENOENT") {
                            return callback({ IsSuccess: false, Message: "Transcript file not available.", Data: null, Error: err }, null);
                        }
                        else {
                            return callback({ IsSuccess: false, Message: "Error occured while reading transcript file in path.", Data: null, Error: err }, null);
                        }
                    } else {
                        responseData.transcriptFileData = transcriptFileData;
                        return callback(null, responseData);
                    }
                });
            }
            else {
                responseData.transcriptFileData = null;
                return callback(null, responseData);
            }
        },
        function (responseData, callback) {
            var videoId = responseData.video.VideoId;
            if (videoId != undefined && videoId != null) {
                videoResourceQuery.getVideoResourcesByVideoId(videoId, function (err, videoResourceResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while fetching video Information.", Data: null, Error: err }, null);
                    }
                    else {
                        responseData.videoResources = videoResourceResponse.rows;
                        return callback(null, responseData);
                    }
                });
            }
            else {
                return callback(null, responseData);
            }
        },
        function (responseData, callback) {
            var videoResources = responseData.videoResources;
            if (videoResources.length > 0) {
                var resourceIds = []
                videoResources.forEach(function (item, index) {
                    resourceIds.push({ DocumentId: item.DocumentId });
                });
                resourceQuery.getResourcesByIds(resourceIds, function (err, resourceResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while fetching video Information.", Data: null, Error: err }, null);
                    }
                    else {
                        responseData.resource = resourceResponse.rows;
                        return callback(null, responseData);
                    }
                });
            }
            else {
                return callback(null, responseData);
            }
        },
        function (responseData, callback) {
            responseData.resourcesFileData = [];
            if (responseData.resource) {
                for (let r = 0; r < responseData.resource.length; r++) {
                    let resourceGuidFileName = responseData.resource[r].Guid + '.' + responseData.resource[r].FileName.split('.').pop();
                    let resourcePath = __dirname + '/../public/resource/' + resourceGuidFileName;
                    fs.readFile(resourcePath, 'base64', (err, resourceFileData) => {
                        if (err) {
                            //costume error message
                            if (err.code == "ENOENT") {
                                return callback({ IsSuccess: false, Message: "Resource file not available.", Data: null, Error: err }, null);
                            }
                            else {
                                return callback({ IsSuccess: false, Message: "Error occured while reading resource file in path.", Data: null, Error: err }, null);
                            }
                        } else {
                            responseData.resourcesFileData.push({ FileData: resourceFileData, Guid: responseData.resource[r].Guid });
                            if (r == responseData.resource.length - 1) {
                                return callback(null, responseData);
                            }
                        }
                    });
                }
            }
            else {
                responseData.resource = [];
                return callback(null, responseData);
            }
        },
        function (responseData, callback) {
            var videoId = responseData.video.VideoId;
            if (videoId != undefined && videoId != null) {
                collectionVideoQuery.getCollectionVideosByVideoId(videoId, function (err, collectionVideoResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while fetching video Information.", Data: null, Error: err }, null);
                    }
                    else {
                        responseData.collectionVideos = collectionVideoResponse.rows;
                        return callback(null, responseData);
                    }
                });
            }
            else {
                return callback(null, responseData);
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: err.message, Data: null, Error: err })
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Video information fetched successfully."
                , Data: responseData
                , Error: null
            });
        }
    });
});

router.put('/UpdateVideoMetadata', function (req, res, next) {
    var video = req.body.video;
    async.waterfall([
        //update video metadata
        function (callback) {
            fileQuery.UpdateVideoMetadata(video, function (err, videoResponse) {
                if (err) {
                    return callback({ IsSuccess: false, Message: "Some error occured while updating video metadata in database.", Data: null, Error: err }, null)
                }
                else {
                    return callback(null, videoResponse);
                }
            })
        },
        //get collection videos by VideoId to delete
        function (videoResponse, callback) {
            let videoId = video.VideoId;
            if (videoId != undefined && videoId != null) {
                collectionVideoQuery.deleteCollectionVideosByVideoId(videoId, function (err, collectionVideosResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while deleting collection videos.", Data: null, Error: err }, null);
                    }
                    else {
                        return callback(null, 'successfully deleted');
                    }
                });
            }
            else {
                return callback(null, 'successfully deleted');
            }
        },
        function (successResponce, callback) {
            if (video.selectedCollections.length > 0 && (video.selectedCollections != undefined || video.selectedCollections != null)) {
                let selectedCollectionsLength = video.selectedCollections.length;
                let selectedCollectionIteration = 0;
                video.selectedCollections.forEach(collectionVideoElement => {
                    var collectionVideo = {
                        CollectionId: collectionVideoElement.id,
                        VideoId: video.VideoId,
                        CreatedBy: 1,
                        CreatedOn: new Date(Date.now()).toISOString()
                    };
                    collectionVideoQuery.CreateCollectionVideo(collectionVideo, function (err, collectionVideoResponse) {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Error occured while creating Collection Video in database.", Data: null, Error: err }, null)
                        }
                        selectedCollectionIteration++;
                        if (selectedCollectionIteration == selectedCollectionsLength) {
                            return callback(null, 'done');
                        }
                    });
                })
            } else {
                return callback(null, 'done');
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while updating video metadata in database. Please try after some time.", Data: null, Error: err })
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "Video updated successfully."
                , Data: {}
                , Error: null
            });
        }
    });
});

router.put('/UpdateVideoFile', function (req, res, next) {
    var newVideo = req.body.newVideo;
    var oldVideo = req.body.oldVideo;
    async.waterfall([
        //delete existing video file if available
        function (callback) {
            let oldVideoGuidFileName = oldVideo.Guid + '.' + oldVideo.FileName.split('.').pop();
            let oldVideoPath = __dirname + '/../public/video/' + oldVideoGuidFileName;
            fs.exists(oldVideoPath, (exists) => {
                if (exists == false) {
                    return callback({ IsSuccess: false, Message: "Error occured while checking video file in server path.", Data: null, Error: 'file not available' }, null);
                }
                else {
                    fs.unlink(oldVideoPath, (err) => {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Error occured while deleting video file in server path.", Data: null, Error: 'file not available' }, null);
                        } else {
                            return callback(null, true);
                        }
                    });
                }
            });
        },
        // upload new video file
        function (fileDeleteResponse, callback) {
            if (fileDeleteResponse) {
                var newVideoGuidFileName = newVideo.Guid + '.' + newVideo.FileName.split('.').pop();
                var newVideoPath = __dirname + '/../public/video/' + newVideoGuidFileName;
                fs.writeFile(newVideoPath, newVideo.FileData, 'base64', (err) => {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while file uploading in existing path.", Data: null, Error: err }, null)
                    } else {
                        return callback(null, true);
                    }
                });
            }
            else {
                return callback(null, false);
            }
        },
        //update file name in database 
        function (fileUploadResponce, callback) {
            if (fileUploadResponce) {
                newVideo.Path = '/../public/video/';
                newVideo.SavedFileName = newVideo.Guid + '_' + newVideo.FileName;
                fileQuery.UpdateVideoMetadata(newVideo, function (err, videoResponse) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Some error occured while updating video file information in database.", Data: null, Error: err }, null)
                    }
                    else {
                        return callback(null, true);
                    }
                })
            } else {
                return callback(null, false);
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while updating video file server. Please try after some time.", Data: null, Error: err })
        } else {
            if (result == true) {
                return res.status(200).send({
                    IsSuccess: true
                    , Message: "Video file updated successfully."
                    , Data: {}
                    , Error: null
                });
            } else {
                return res.status(500).send({ IsSuccess: false, Message: "Some error occured while updating video file server. Please try after some time.", Data: null, Error: err })
            }
        }
    });
});

router.put('/UpdateTranscriptFile', function (req, res, next) {
    var newTranscript = req.body.newTranscript;
    var oldTranscript = req.body.oldTranscript;
    async.waterfall([
        //delete existing transcript file if available
        function (callback) {
            if (oldTranscript) {
                let oldTranscriptGuidFileName = oldTranscript.Guid + '.' + oldTranscript.FileName.split('.').pop();
                let oldTranscriptPath = __dirname + '/../public/transcript/' + oldTranscriptGuidFileName;
                fs.exists(oldTranscriptPath, (exists) => {
                    if (exists == false) {
                        return callback({ IsSuccess: false, Message: "Error occured while checking transcript file in server path.", Data: null, Error: 'file not available' }, null);
                    }
                    else {
                        fs.unlink(oldTranscriptPath, (err) => {
                            if (err) {
                                return callback({ IsSuccess: false, Message: "Error occured while deleting transcript file in server path.", Data: null, Error: 'file not available' }, null);
                            } else {
                                return callback(null, true);
                            }
                        });
                    }
                });
            }
            else {
                return callback(null, true);
            }
        },
        // upload new video file
        function (fileDeleteResponse, callback) {
            if (fileDeleteResponse) {
                if (!oldTranscript) {
                    newTranscript.Guid = guid.create().toString();
                }
                var newTranscriptGuidFileName = newTranscript.Guid + '.' + newTranscript.FileName.split('.').pop();
                var newTranscriptPath = __dirname + '/../public/transcript/' + newTranscriptGuidFileName;
                fs.writeFile(newTranscriptPath, newTranscript.FileData, 'base64', (err) => {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while transcript file uploading in existing path.", Data: null, Error: err }, null)
                    } else {
                        return callback(null, true);
                    }
                });
            }
            else {
                return callback(null, false);
            }
        },
        //update file name in database 
        function (fileUploadResponce, callback) {
            if (fileUploadResponce) {
                newTranscript.Path = '/../public/transcript/';
                newTranscript.SavedFileName = newTranscript.Guid + '_' + newTranscript.FileName;
                if (!oldTranscript) {
                    newTranscript.Title = "Manually Added";
                    newTranscript.Language = "English";
                    fileQuery.UploadTranscript(newTranscript, function (err, response) {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Some error occured while updating transcript file information in database.", Data: null, Error: err }, null);
                        }
                        else {
                            return callback(null, true);
                        }
                    });
                }
                else {
                    fileQuery.UpdateTranscriptMetadata(newTranscript, function (err, transcriptResponse) {
                        if (err) {
                            return callback({ IsSuccess: false, Message: "Some error occured while updating transcript file information in database.", Data: null, Error: err }, null);
                        }
                        else {
                            return callback(null, true);
                        }
                    })
                }
            } else {
                return callback(null, false);
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while updating transcript file server. Please try after some time.", Data: null, Error: err })
        } else {
            if (result == true) {
                return res.status(200).send({
                    IsSuccess: true
                    , Message: "Transcript file updated successfully."
                    , Data: {}
                    , Error: null
                });
            } else {
                return res.status(500).send({ IsSuccess: false, Message: "Some error occured while updating transcript file server. Please try after some time.", Data: null, Error: err })
            }
        }
    });
});

router.put('/DeleteResourceFile', function (req, res, next) {
    var videoId = req.body.videoId;
    var resource = req.body.resource;
    async.waterfall([
        //delete existing resource file if available
        function (callback) {
            if (resource.Guid) {
                let resourceGuidFileName = resource.Guid + '.' + resource.FileName.split('.').pop();
                let resourcePath = __dirname + '/../public/resource/' + resourceGuidFileName;
                fs.exists(resourcePath, (exists) => {
                    if (exists == false) {
                        return callback({ IsSuccess: false, Message: "Error occured while checking resource file in server path.", Data: null, Error: 'file not available' }, null);
                    }
                    else {
                        fs.unlink(resourcePath, (err) => {
                            if (err) {
                                return callback({ IsSuccess: false, Message: "Error occured while deleting resource file in server path.", Data: null, Error: 'file not available' }, null);
                            } else {
                                return callback(null, true);
                            }
                        });
                    }
                });
            }
            else {
                return callback(null, true);
            }
        },
        function (deleteRes, callback) {
            if (deleteRes) {
                videoResourceQuery.DeleteVideoResource(videoId, resource.DocumentId, function (err, videoResourceRes) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while creating Video Resource in database.", Data: null, Error: err }, null);
                    }
                    else {
                        return callback(null, true);
                    }
                });
            }
            else {
                return callback(null, true);
            }
        },
        function (deleteVideoResource, callback) {
            if (deleteVideoResource) {
                resourceQuery.DeleteResource(resource.DocumentId, resource.Guid, function (err, response) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while creating Video Resource in database.", Data: null, Error: err }, null);
                    }
                    else {
                        return callback(null, true);
                    }
                });
            }
            else {
                return callback(null, true);
            }
        }

    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while deleting resource file server. Please try after some time.", Data: null, Error: err })
        } else {
            if (result == true) {
                return res.status(200).send({
                    IsSuccess: true
                    , Message: "Resource file deleted successfully."
                    , Data: {}
                    , Error: null
                });
            } else {
                return res.status(500).send({ IsSuccess: false, Message: "Some error occured while deleting resource file server. Please try after some time.", Data: null, Error: err })
            }
        }
    });
});

router.post('/CreateResourceFileForVideo', function (req, res, next) {
    var videoId = req.body.videoId;
    var resource = req.body.resource;
    resource.Guid = guid.create().toString();
    resource.Title = null;
    resource.Description = null;
    resource.Type = resource.FileType;
    resource.Path = '/../public/resource/';
    resource.Tags = null;
    resource.Ratings = null;
    resource.Path = '/../public/resource/';
    resource.SavedFileName = resource.Guid + '_' + resource.FileName;
    var resourceGuidFileName = resource.Guid + '.' + resource.FileName.split('.').pop();
    var resourcePath = __dirname + '/../public/resource/' + resourceGuidFileName;
    async.waterfall([
        //create resource file in a path
        function (callback) {
            //var resourceDirectory = path.join(__dirname, '/../public/resource');
            //fs.existsSync(resourceDirectory) || fs.mkdirSync(resourceDirectory);
            fs.writeFile(resourcePath, resource.FileData, 'base64', (err) => {
                if (err) {
                    return callback({ IsSuccess: false, Message: "Error occured while uploading Video Resource.", Data: null, Error: err }, null);
                }
                else {
                    return callback(null, true);
                }
            });
        },
        function (fileUploadRes, callback) {
            if (fileUploadRes) {
                resourceQuery.CreateResource(resource, function (err, response) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while creating Resource.", Data: null, Error: err }, null);
                    }
                    else {
                        return callback(null, true, response);
                    }
                });
            }
            else {
                return callback(null, false, null);
            }
        },
        function (fileResourceRes, responceData, callback) {
            if (fileResourceRes && responceData) {
                var videoResource = {
                    VideoId: videoId,
                    DocumentId: responceData.DocumentId
                };

                videoResourceQuery.CreateVideoResource(videoResource, function (err, videoResourceRes) {
                    if (err) {
                        return callback({ IsSuccess: false, Message: "Error occured while creating Video Resource in database.", Data: null, Error: err }, null)
                    }
                    else {
                        return callback(null, responceData);
                    }
                });
            }
            else {
                return callback(null, false);
            }
        }
    ], function (err, result) {
        if (err) {
            return res.status(500).send({ IsSuccess: false, Message: "Some error occured while creating video resource in server. Please try after some time.", Data: null, Error: err })
        } else {
            if (result == false) {
                return res.status(500).send({ IsSuccess: false, Message: "Some error occured while creating video resource in server. Please try after some time.", Data: null, Error: err })
            }
            else {
                return res.status(200).send({
                    IsSuccess: true
                    , Message: "Resource file uploaded successfully."
                    , Data: result
                    , Error: null
                });
            }
        }
    });
});


module.exports = router;