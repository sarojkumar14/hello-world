const router = require('express').Router();
const watchLaterQuery = require('../Data/watchLater.data')

router.post('/create', function (req, res, next) {
    let watch = req.body.data;
    watchLaterQuery.createWatchLater(watch, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in added history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history added successfully."
                , Data: response
                , Error: null
            });
        }
    })
})

router.get('/watchLaterByUser', function (req, res, next) {
    let userId = req.param('userId');
    watchLaterQuery.getWatchLaterByUser(userId, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in getting history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history retrieved successfully."
                , Data: response
                , Error: null
            });
        }
    })
});

router.get('/removeWatchLater', function (req, res, next) {
    let watchId = req.param('watchId');
    watchLaterQuery.removeWatchLater(watchId, function (err, response) {
        if (err) {
            return res.status(500).send(
                {
                    IsSuccess: false
                    , Message: "Error occured in removing history."
                    , Data: null
                    , Error: err
                });
        } else {
            return res.status(200).send({
                IsSuccess: true
                , Message: "history removed successfully."
                , Data: response
                , Error: null
            });
        }
    })
})


module.exports = router;