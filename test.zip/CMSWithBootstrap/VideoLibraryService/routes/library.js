const express = require('express');
const router = express.Router();
const fs = require('fs');
const libQuery = require('../Data/library.data')

router.post('/create', function (req, res, next) {
    var data = req.body;
    var path = __dirname + '/../public/libraryImage/' + data.image.filename;
    fs.writeFile(path, data.image.fileData, 'base64', (err) => {
        // throws an error, you could also catch it here
        if (err) {
            return res.status('500').send({ error: "Error occured in File processing." })
        }
        libQuery.createLibrary(data, function (err, response) {
            if (err) {
                return res.status('500').send({ error: "Error occured while processing." })
            }
            return res.send(response);
        })
    });
});

router.get('/getAllLibrary', function (req, res, next) {
    libQuery.getAllLibrary(function (err, response) {
        if (err) {
            return res.status('500').send({ error: "Error occured while processing." })
        }
        return res.send(response.rows);
    })
})

router.post('/deleteLibrary', function (req, res, next) {
    var id = req.body.Id;
    libQuery.deleteLibrary(id, function (err, response) {
        if (err) {
            return res.status('500').send({ error: "Error occured while processing." })
        }
        return res.send({ message: 'Data deleted successfuly' });
    })
})

module.exports = router;