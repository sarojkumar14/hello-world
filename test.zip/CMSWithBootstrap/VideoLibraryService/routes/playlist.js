const express = require('express');
const router = express.Router();
const playlistQuery = require('../data/playlist.data');

router.post('/createplaylist', function (req, res) {

    let data = req.body;
    let title = data.Title;
    if (title == undefined) {
        res.status(500).send({
            success: false,
            message: 'Something failed!'
        });
    }
    playlistQuery.createPlaylist(data, function (err, result) {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: 'Something failed!'
            });
        } else {
            if (typeof result === "object") {
                res.status(200).json({
                    success: true,
                    message: "Created successfully",
                    data: result
                });
            } else {
                res.status(200).json({
                    success: false,
                    message: "Playlist already exist.",
                    data: result
                });
            }
        }
    });
});


router.post("/playlistcountbyuser", (req, res) => {
    let data = req.body;

    playlistQuery.playlistCountByUser(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: 'Something failed!'
            });
        } else {
            res.status(200).json({
                success: true,
                message: "",
                data: result
            });
        }
    })
})


router.post("/getplaylistbyuser", (req, res) => {
    let data = req.body;
    playlistQuery.getPlaylistByUser(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: 'Something failed!'
            });
        } else {
            res.status(200).json({
                success: true,
                message: "",
                data: result
            });
        }
    })
})

router.post("/addvideotoplaylist", (req, res) => {
    let data = req.body;
    playlistQuery.addVideoToPlaylist(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: 'Something failed!'
            });
        } else {
            res.status(200).json({
                success: true,
                message: `Video added in the ${data.playlistTitle}.`,
                data: result
            });
        }
    })
})

router.post('/removeplaylist', function (req, res) {
    let data = req.body;
    playlistQuery.removeplaylist(data.PlaylistId, function (err, result) {
        if (result == 1) {
            res.send({
                success: true,
                data: "Deleted successfully!!"
            })
        } else {
            res.status(500).send({
                success: false,
                data: "Undeleted successfully!!"
            })
        }
    });
});

router.patch('/updateplaylist', function (req, res) {

    let data = req.body;
    console.log(data)
    let title = data.Title;
    if (title == undefined) {
        res.status(500).send({
            error: 'Something failed'
        });
    }
    playlistQuery.updateplaylist(data, function (err, result) {
        if (err || result == null) {
            res.status(500).json({
                error: 'Something failed!'
            });
        } else {
            res.json(result);
        }
    });
});


router.post("/getplaylistvideo", (req, res) => {
    let data = req.body;
    playlistQuery.getPlaylistVideo(data, (err, result) => {
        if (err || result == null) {
            res.status(500).json({
                success: false,
                message: 'Something failed!'
            });
        } else {
            res.status(200).json({
                success: true,
                message: "Fetched successfully.",
                data: result
            });
        }
    })
})


router.post('/removevideofromplaylist', function (req, res) {
    let data = req.body;
    playlistQuery.removeVideoFromPlaylist(data.PlaylistVideoId, function (err, result) {
        if (result == 1) {
            res.send({
                success: true,
                data: "Deleted successfully!!"
            })
        } else {
            res.status(500).send({
                success: false,
                data: "Undeleted successfully!!"
            })
        }
    });
});


module.exports = router;