const express = require('express');
const router = express.Router();
const authQuery = require('../data/auth.data');
const config = require('../global/config');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt');

router.post('/', function (req, res) {
    var data = req.body;
    var username = data.username;
    var password = data.password;

    if (username == undefined && password == undefined) {
        return res.status(500).send({
            error: 'Username or password is not defined'
        });
    }

    authQuery.authenticate(username, password, function (err, data) {
        if (err) {
            return res.status(500).send({
                IsSuccess: false,
                Message: "Something failed! Please try after sometime",
                Data: null
            })
        } else if (data == null) {
            //Need to change this validation. Exposing security threat. Change as "Username and password not in our database"
            return res.status(404).send({
                IsSuccess: false,
                Message: "Username is not in our database.",
                Data: null
            })
        } else {
            bcrypt.compare(req.body.password, data.Password, function (err, isEqual) {
                if (isEqual) {
                    var payload = {
                        role: data.SMSRole.RoleName,
                        name: data.FirstName,
                        username: data.Username
                    }

                    var token = jwt.sign(payload, config.secret, {
                        expiresIn: config.tokenexp // expires in 24 hours
                    });

                    return res.send({
                        IsSuccess: true,
                        Message: "Successfully authenticated",
                        Data: data,
                        token: token
                    })
                } else {
                    //Need to change this validation. Exposing security threat. change message as "Username and password is incorrect"
                    return res.status(500).send({
                        IsSuccess: true,
                        Message: "Incorrect password",
                        Data: null
                    })
                }
            });
        }
    });
});

router.post('/register', function (req, res) {
    var data = req.body;
    //check user exist or not. if exist throw an error
    authQuery.isUserExist(data, function (err, isUserExistResponse) {
        if (err) {
            return res.send({
                IsSuccess: false,
                Message: "Error occured while checking user registered or not.",
                Data: null,
                Error: err
            })
        } else if (isUserExistResponse) {
            if ((data.emailId != isUserExistResponse.EmailId) && (data.userName == isUserExistResponse.UserName)) {
                return res.send({
                    IsSuccess: false,
                    Message: "Already user name " + data.userName + " used by some one. Please try with another one.",
                    Data: null,
                    Error: null
                })
            } else if (((data.emailId == isUserExistResponse.EmailId) && (data.userName != isUserExistResponse.UserName)) || ((data.userName == isUserExistResponse.UserName) && (data.emailId == isUserExistResponse.EmailId))) {
                //Please explain this condition to me - Aneesh
                return res.send({
                    IsSuccess: false,
                    Message: "You have already registered.",
                    Data: null,
                    Error: null
                })
            }
        } else if (!isUserExistResponse) {
            authQuery.register(data, function (err, registerResponse) {
                if (err) {
                    return res.send({
                        IsSuccess: false,
                        Message: "User registeration failed. Please try after some time.",
                        Data: null,
                        Error: err
                    })
                } else {
                    authQuery.updateUser(registerResponse, function (err, newUser) {
                        if (err) {
                            return res.send({
                                IsSuccess: false,
                                Message: "User registeration failed. Please try after some time.",
                                Data: null,
                                Error: err
                            })
                        } else {

                            return res.send({
                                IsSuccess: true,
                                Message: "You have registered successfully. Please validate your mail id.",
                                Data: newUser
                            });
                        }
                    });
                }
            });
        }
    })
});
module.exports = router;