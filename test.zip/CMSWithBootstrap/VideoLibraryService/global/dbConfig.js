module.exports = {
    "username": "pearson",
    "password": "Pearson@123",
    "server": "integra-net4",
    "database": "PearsonVideoSearch",
    "dialect": "mssql"
}