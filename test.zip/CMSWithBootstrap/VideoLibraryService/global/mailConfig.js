module.exports = {
    "host": "",
    "port": "",
    "secure": "",
    "username": "",
    "password": ""
}