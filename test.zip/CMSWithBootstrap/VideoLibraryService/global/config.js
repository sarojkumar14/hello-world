const path=require('path');

module.exports = {
    'serverport':3000,
    'tokenexp': 86400,
    'secret': 'videolibserver',
    'galaryImage':'',
    'videopath':''
}