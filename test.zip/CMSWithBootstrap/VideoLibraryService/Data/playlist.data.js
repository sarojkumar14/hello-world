const models = require('../models');

function isPlaylistAlreadyExistUser(userid, title) {
    return models.Playlist.findOne({
            where: {
                UserId: userid,
                Title: title
            }
        })
        .then(value => {
            console.log(value)
            if (value == null) {
                return false;
            }
            return true;
        });
}

let createPlaylist = function (data, callback) {
    console.log(data);
    isPlaylistAlreadyExistUser(data.UserId, data.Title).then(function (isExist) {
        console.log("SS")
        console.log(isExist)
        if (!isExist) {
            models.Playlist.create({
                Title: data.Title,
                Description: data.Description,
                UserId: data.UserId,
                CreatedOn: data.CreatedOn,
                CreatedBy: data.CreatedBy,
                UpdatedOn: data.UpdatedOn,
                UpdatedBy: data.UpdatedBy
            }).then(result => {
                console.log(result.get({
                    plain: true
                }))
                let res = result.get({
                    plain: true
                });
                console.log(data.VideoId)
                if (data.VideoId != undefined) {
                    if (data.VideoId != null || data.VideoId != 0) {
                        console.log("SDs")
                        let playlistVidObj = {
                            VideoId: data.VideoId,
                            PlaylistId: res.PlaylistId,
                            CreatedOn: data.CreatedOn,
                            CreatedBy: data.CreatedBy
                        }
                        addVideoToPlaylist(playlistVidObj, callback)
                    } else {
                        callback(null, result);
                    }
                } else {
                    callback(null, result);
                }

            }).catch(function (err) {
                console.log(err)
                callback(err);
            });
        } else {
            callback(null, false);
        }
    })
}


let playlistCountByUser = (data, callback) => {
    models.Playlist.count({
        where: {
            UserId: data.UserId,
            IsRemoved: false
        }
    }).then((result) => {
        callback(null, result);
    }).catch((err) => {
        callback(err);
    })
}

let getPlaylistByUser = (data, callback) => {

    models.sequelize.query(`SELECT P.Title,P.PlaylistId, 
                            ISNULL((SELECT COUNT(VideoId) FROM PlaylistVideo WHERE IsRemoved = 0 
                            and P.PlaylistId = PlaylistVideo.PlaylistId GROUP BY PlaylistId),0) VideoCount,
                            MAX(Description) Description FROM Playlist P 
                            LEFT JOIN PlaylistVideo PV ON P.PlaylistId = PV.PlaylistId 
                            WHERE P.UserId = ${data.UserId} and P.IsRemoved = 0
                            GROUP BY P.Title,P.PlaylistId`, {
        type: models.sequelize.QueryTypes.SELECT
    }).then(projects => {
        callback(null, projects);
    }).catch(function (err) {
        callback(err);
    });
}

let addVideoToPlaylist = (data, callback) => {
    models.PlaylistVideo.create({
        PlaylistId: data.PlaylistId,
        VideoId: data.VideoId,
        CreatedOn: data.CreatedOn,
        CreatedBy: data.CreatedBy
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        console.log(err)
        callback(err);
    });
}

var removeplaylist = function (PlaylistId, callback) {
    models.Playlist.update({
        IsRemoved: true
    }, {
        where: {
            PlaylistId: PlaylistId
        }
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err);
    });
};

var updateplaylist = function (data, callback) {
    models.Playlist.update({
        Title: data.Title,
        Description: data.Description,
        UserId: data.UserId,
        CreatedOn: data.CreatedOn,
        CreatedBy: data.CreatedBy,
        UpdatedOn: data.UpdatedOn,
        UpdatedBy: data.UpdatedBy
    }, {
        where: {
            PlaylistId: data.PlaylistId
        }
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        console.log(err)
        callback(err);
    });
};

let getPlaylistVideo = (data, callback) => {

    models.sequelize.query(`SELECT V.*,P.Title PlaylistName, U.FirstName, PV.PlaylistId,PV.PlaylistVideoId from PlaylistVideo PV
                            INNER JOIN Video V ON PV.VideoId = V.VideoId
                            INNER JOIN Playlist P ON P.PlaylistId = PV.PlaylistId
                            INNER JOIN SMSUser U ON U.UserId = V.CreatedBy
                            WHERE PV.PlaylistId = ${data.PlaylistId} and PV.IsRemoved = 0`, {
        type: models.sequelize.QueryTypes.SELECT
    }).then(projects => {
        callback(null, projects);
    }).catch(function (err) {
        callback(err);
    });
}

var removeVideoFromPlaylist = function (PlaylistVideoId, callback) {
    models.PlaylistVideo.update({
        IsRemoved: true
    }, {
        where: {
            PlaylistVideoId: PlaylistVideoId
        }
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err);
    });
};


module.exports = {
    createPlaylist: createPlaylist,
    playlistCountByUser: playlistCountByUser,
    getPlaylistByUser: getPlaylistByUser,
    addVideoToPlaylist: addVideoToPlaylist,
    updateplaylist: updateplaylist,
    removeplaylist: removeplaylist,
    updateplaylist: updateplaylist,
    getPlaylistVideo: getPlaylistVideo,
    removeVideoFromPlaylist: removeVideoFromPlaylist
}