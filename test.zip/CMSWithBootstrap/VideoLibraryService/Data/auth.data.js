const models = require('../models');
var Sequelize = require('sequelize');
const Op = Sequelize.Op;

var authenticate = function (username, password, callback) {
    models.SMSUser.findOne({
        where: {
            Username: username
        },
        include: ['SMSRole']
    }).then(dash => {
        callback(null, dash);
    }).catch(function (err) {
        callback(err);
    });
};

let isUserExist = function (smsUser, callback) {
    models.SMSUser.findOne({
        where: {
            [Op.or]: [{ UserName: smsUser.userName }, { EmailId: smsUser.emailId }]
        }
    }).then(response => {
        callback(null, response);
    }).catch(function (err) {
        callback(err);
    });
};

let register = function (smsUser, callback) {
    models.SMSUser.create({
        UserName: smsUser.userName,
        FirstName: smsUser.firstName,
        MiddleName: smsUser.middleName,
        LastName: smsUser.lastName,
        EmailId: smsUser.emailId,
        Password: smsUser.password,
        RoleId: smsUser.roleId,
        SecurityQuestionId: smsUser.securityQuestionId,
        SecurityAnswer: smsUser.securityAnswer,
        CreatedOn: smsUser.createdOn,
        CreatedBy: smsUser.createdBy,
        UpdatedOn: smsUser.updatedOn,
        UpdatedBy: smsUser.updatedBy
    })
        .then(createdUser => {
            callback(null, createdUser);
        }).catch(function (err) {
            callback(err);
        });
};

let updateUser = function (smsUser, callback) {
    models.SMSUser.update({
        UserName: smsUser.UserName,
        FirstName: smsUser.FirstName,
        MiddleName: smsUser.MiddleName,
        LastName: smsUser.LastName,
        EmailId: smsUser.EmailId,
        Password: smsUser.Password,
        RoleId: smsUser.RoleId,
        SecurityQuestionId: smsUser.SecurityQuestionId,
        SecurityAnswer: smsUser.SecurityAnswer,
        CreatedOn: smsUser.CreatedOn,
        CreatedBy: smsUser.UserId,
        UpdatedOn: smsUser.UpdatedOn,
        UpdatedBy: smsUser.UserId
    },
        {
            where: {
                UserId: smsUser.UserId
            }
        }).then(response => {
            callback(null, response);
        }).catch(function (err) {
            callback(err);
        });
};

module.exports = {
    authenticate: authenticate,
    isUserExist: isUserExist,
    register: register,
    updateUser: updateUser
};