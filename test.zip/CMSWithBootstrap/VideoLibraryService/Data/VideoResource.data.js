const models = require('../models');

let CreateVideoResource = function (videoResource, callback) {
    models.VideoResource.create(videoResource)
        .then(res => {
            callback(null, res);
        }).catch(function (err) {
            callback(err);
        });
};

let getVideoResourcesByVideoId = function (videoId, callback) {
    models.VideoResource.findAndCountAll({
        where: {
            VideoId: videoId
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

let DeleteVideoResource = function (videoId, documentId, callback) {
    models.VideoResource.destroy({
        where: {
            VideoId: videoId,
            DocumentId: documentId
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

module.exports = {
    CreateVideoResource: CreateVideoResource,
    getVideoResourcesByVideoId: getVideoResourcesByVideoId,
    DeleteVideoResource: DeleteVideoResource
};