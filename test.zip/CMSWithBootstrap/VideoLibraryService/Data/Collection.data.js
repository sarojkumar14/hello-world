const models = require('../models');
var Sequelize = require('sequelize');
const Op = Sequelize.Op;

var createcollection = function (videocollection, callback) {
    models.Collection.create({
        CollectionName: videocollection.CollectionName,
        Description: videocollection.Description,
        CreatedOn: videocollection.CreatedOn,
        CreatedBy: videocollection.CreatedBy,
        UpdatedOn: videocollection.UpdatedOn,
        UpdatedBy: videocollection.UpdatedBy
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        console.log(err)
        callback(err);
    });
};

var getCollectionByUserRole = function (obj, callback) {
    if (obj.RoleId == 1) {
        models.Collection.findAll().then(result => {
            callback(null, result);
        }).catch(function (err) {
            callback(err);
        });
    } else {
        models.sequelize.query(`SELECT Collection.CollectionId, MAX(CollectionName) CollectionName FROM Collection INNER JOIN CollectionUser 
                                ON Collection.CollectionId = CollectionUser.CollectionId
                                WHERE UserId = ${obj.UserId}
                                GROUP BY Collection.CollectionId`, {
            replacements: {
                userId: obj.UserId
            },
            type: models.sequelize.QueryTypes.SELECT
        }).then(projects => {
            callback(null, projects);
        }).catch(function (err) {
            callback(err);
        });
    }
};

var removecollection = function (CollectionId, callback) {
    models.Collection.destroy({
        where: {
            CollectionId: CollectionId
        }
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err);
    });
};

var updatecollection = function (videocollection, callback) {
    models.Collection.update({
        CollectionId: videocollection.CollectionId,
        CollectionName: videocollection.CollectionName,
        Description: videocollection.Description,
        UpdatedOn: videocollection.UpdatedOn,
        UpdatedBy: videocollection.UpdatedBy
    }, {
        where: {
            CollectionId: videocollection.CollectionId
        }
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        console.log(err)
        callback(err);
    });
};

let getUserCollections = function (callback) {
    models.Collection.findAndCountAll()
        .then(resData => {
            callback(null, resData);
        }).catch(function (err) {
            callback(err);
        });
};

let getUserCollectionVideos = function (data, callback) {
    console.log(data)
    let adminAllQuery = `SELECT * FROM Collection 
    INNER JOIN CollectionVideo ON Collection.CollectionId = CollectionVideo.CollectionId
    INNER JOIN Video ON Video.VideoId = CollectionVideo.VideoId`;

    let adminCollectionQuery = `${adminAllQuery} and Collection.CollectionId = ${data.CollectionId}`;

    let userAllQuery = `SELECT Video.*,Collection.CollectionName,U.FirstName, CollectionVideo.CollectionId FROM Collection 
                        INNER JOIN CollectionVideo ON Collection.CollectionId = CollectionVideo.CollectionId
                        INNER JOIN Video ON Video.VideoId = CollectionVideo.VideoId 
                        INNER JOIN CollectionUser ON Collection.CollectionId = CollectionUser.CollectionId and CollectionUser.CollectionId = CollectionVideo.CollectionId
                        INNER JOIN SMSUser U ON U.UserId = Video.CreatedBy
                        where CollectionUser.UserId = ${data.UserId}`

    let userCollectionQuery = `${userAllQuery} and  Collection.CollectionId = ${data.CollectionId}`

    let setAdminQuery = (data.RoleId == 1 && data.CollectionId == 0) ? adminAllQuery : adminCollectionQuery;

    let setUserQuery = (data.RoleId != 1 && data.CollectionId == 0) ? userAllQuery : userCollectionQuery;

    let setQuery = data.RoleId == 1 ? setAdminQuery : setUserQuery;

    models.sequelize.query(setQuery, {
        type: models.sequelize.QueryTypes.SELECT
    }).then(projects => {
        callback(null, projects);
    }).catch(function (err) {
        callback(err);
    });
}

let readVideoTranscript = function (data, callback) {
    console.log(data)
    let lang = data.language;
    var readVideoInterface = readline.createInterface({
        input: fs.createReadStream(`./public/transcript/captions.${lang}.vtt`, {
            encoding: 'utf8'
        })
    });
    var linebyline = [];
    readVideoInterface.on('line', function (line) {
        // console.log(line.split(" -->"));
        // line.forEach(function (element) {
        //     console.log()
        // })
        //console.log()
        linebyline.push(line);
    });
    readVideoInterface.on('close', function (data) {
        callback(null, linebyline)
    });
}


let getAllVideos = function (callback) {
    models.Video.findAll({}).then(function (response) {
        callback(null, response)
    }).catch(function (err) {
        console.log(err)
        callback(err)
    })
}

let adminSelectVideoToCollection = function (data, callback) {
    models.CollectionVideo.create({
        CollectionId: data.CollectionId,
        VideoId: data.VideoId,
        CreatedOn: data.CreatedOn,
        CreatedBy: data.CreatedBy,
        UpdatedOn: data.UpdatedOn,
        UpdatedBy: data.UpdatedBy
    }).then((response) => {
        callback(null, response);
    }).catch((err) => {
        callback(err)
    })
}

let getAllUsers = function (callback) {
    models.SMSUser.findAll({
        attributes: ['UserId', 'UserName', 'RoleId', [models.sequelize.literal("FirstName + ' ' + LastName"), 'FullName']],
        where: {
            RoleId: {
                [Op.notIn]: [1]
            }
        }
    }).then(function (response) {
        callback(null, response)
    }).catch(function (err) {
        console.log(err)
        callback(err)
    })
}

let adminLinkCollectionToUser = function (data, callback) {
    console.log(data)
    models.CollectionUser.create({
        CollectionId: data.CollectionId,
        UserId: data.UserId,
        CreatedOn: data.CreatedOn,
        CreatedBy: data.CreatedBy,
        UpdatedOn: data.UpdatedOn,
        UpdatedBy: data.UpdatedBy
    }).then((response) => {
        callback(null, response);
    }).catch((err) => {
        console.log(err);
        callback(err)
    })
}

let getCollectionCount = (data, callback) => {
    if (data.RoleId == 1) {
        models.Collection.count().then(result => {
            callback(null, result);
        }).catch(function (err) {
            callback(err);
        });
    } else {
        models.sequelize.query(`SELECT SUM(CountCollect) as CollectinCountUser
                                FROM (SELECT COUNT(DISTINCT  CollectionId) CountCollect
                                FROM CollectionUser
                                WHERE UserId = ${data.UserId}
                                GROUP BY CollectionId) ColUser`, {
            replacements: {
                userId: data.UserId
            },
            type: models.sequelize.QueryTypes.SELECT
        }).then(projects => {
            callback(null, projects[0].CollectinCountUser);
        }).catch(function (err) {
            callback(err);
        });
    }
}

module.exports = {
    createcollection: createcollection,
    updatecollection: updatecollection,
    getCollectionByUserRole: getCollectionByUserRole,
    removecollection: removecollection,
    getUserCollections: getUserCollections,
    getUserCollectionVideos: getUserCollectionVideos,
    readVideoTranscript: readVideoTranscript,
    getAllVideos: getAllVideos,
    adminSelectVideoToCollection: adminSelectVideoToCollection,
    getAllUsers: getAllUsers,
    adminLinkCollectionToUser: adminLinkCollectionToUser,
    getCollectionCount: getCollectionCount
}