const models = require('../models');

let createHistory = function (video, callback) {

    models.WatchHistory.count({
        where: {
            VideoId: video.VideoId
        }
    }).then(res => {
        if (res > 0) {
            models.sequelize.query(`UPDATE WatchHistory SET WatchedOn=getdate() WHERE VideoId = ${video.VideoId}`, {
                type: models.sequelize.QueryTypes.UPDATE
            }).then(updateRes => {
                callback(null, updateRes);
            }).catch(function (err) {
                callback(err);
            });
        } else {
            models.WatchHistory.create(video)
                .then(res => {
                    callback(null, res);
                }).catch(function (err) {
                    callback(err);
                });
        }
    }).catch(function (err) {
        callback(err);
    });
};

let removeHistory = function (watchId, callback) {
    models.WatchHistory.destroy({
        where: {
            WatchId: watchId
        }
    })
        .then(response => {
            callback(null, response);
        }).catch(function (err) {
            callback(err);
        });
}


let getWatchedHistoryByUser = function (userId, callback) {
    models.sequelize.query(`SELECT WatchId,wh.VideoId
      ,wh.UserId,wh.WatchedOn
      ,wh.CreatedOn,wh.CreatedBy
	  ,vdo.Guid,vdo.FileName
      ,vdo.Title,vdo.StandaloneURL
      ,vdo.EmbededURL,vdo.Description
      ,vdo.ViewCount,vdo.Type
      ,vdo.Path,vdo.Size
      ,vdo.Tags,vdo.Rating
      ,vdo.Privacy,vdo.Owner
      ,vdo.Topic,vdo.Grade,vdo.Unit
    FROM WatchHistory wh
    INNER JOIN Video vdo ON vdo.VideoId=wh.VideoId
    WHERE wh.UserId=${userId}
    ORDER BY wh.WatchedOn DESC`, {
            type: models.sequelize.QueryTypes.SELECT
        }).then(response => {
            callback(null, response);
        }).catch(function (err) {
            callback(err);
        });
}

module.exports = {
    createHistory: createHistory,
    getWatchedHistoryByUser: getWatchedHistoryByUser,
    removeHistory: removeHistory
}