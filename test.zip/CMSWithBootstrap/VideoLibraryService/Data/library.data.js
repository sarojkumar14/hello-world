const models = require('../models');

let createLibrary = function (library, callback) {
    models.ResourceLibrary.create({ Name: library.name, Description: library.description, Image: library.image.filename })
        .then(lib => {
            callback(null, lib);
        }).catch(function (err) {
            callback(err);
        });
};

let getAllLibrary = function (callback) {
    models.ResourceLibrary.findAndCountAll()
        .then(lib => {
            callback(null, lib);
        }).catch(function (err) {
            callback(err);
        });
};

let deleteLibrary = function (id, callback) {
    models.ResourceLibrary.destroy({
        where: {
            Id: id
        }
    })
        .then(lib => {
            callback(null, lib);
        }).catch(function (err) {
            callback(err);
        });
}

module.exports = {
    createLibrary: createLibrary,
    getAllLibrary: getAllLibrary,
    deleteLibrary: deleteLibrary
};