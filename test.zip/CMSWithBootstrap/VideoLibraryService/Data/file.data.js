const models = require('../models');

let UploadVideo = function (video, callback) {
    models.Video.create(video)
        .then(res => {
            callback(null, res);
        }).catch(function (err) {
            callback(err);
        });
};
let UploadTranscript = function (transcript, callback) {
    models.Transcript.create(transcript)
        .then(res => {
            callback(null, res);
        }).catch(function (err) {
            callback(err);
        });
};

let updateViewCount = function (videoId, callback) {

    models.sequelize.query(`UPDATE Video SET ViewCount=Coalesce(ViewCount, 0)+1 WHERE VideoId = ${videoId}`, {
        type: models.sequelize.QueryTypes.UPDATE
    }).then(response => {
        callback(null, response);
    }).catch(function (err) {
        callback(err);
    });
}

let getVideoById = function (guid, callback) {
    models.Video.findOne({
        where: {
            Guid: guid
        }
    }).then(video => {
        callback(null, video);
    }).catch(function (err) {
        callback(err, null);
    });
}

let getTranscriptByVideoId = function (videoId, callback) {
    models.Transcript.findOne({
        where: {
            VideoId: videoId
        }
    }).then(transcript => {
        callback(null, transcript);
    }).catch(function (err) {
        callback(err, null);
    });
}

let UpdateVideoMetadata = function (video, callback) {
    models.Video.update(video, {
        where: {
            VideoId: video.VideoId,
            Guid: video.Guid
        },
        returning: true,
        plain: true
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err, null);
    });
}

let UpdateTranscriptMetadata = function (transcript, callback) {
    models.Transcript.update(transcript, {
        where: {
            TranscriptId: transcript.TranscriptId,
            VideoId: transcript.VideoId,
            Guid: transcript.Guid
        },
        returning: true,
        plain: true
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err, null);
    });
}

module.exports = {
    UploadVideo: UploadVideo,
    UploadTranscript: UploadTranscript,
    updateViewCount: updateViewCount,
    getVideoById: getVideoById,
    getTranscriptByVideoId: getTranscriptByVideoId,
    UpdateVideoMetadata: UpdateVideoMetadata,
    UpdateTranscriptMetadata: UpdateTranscriptMetadata
};