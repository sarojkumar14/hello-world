const models = require('../models');

let CreateCollectionVideo = function (collectionVideo, callback) {
    models.CollectionVideo.create(collectionVideo)
        .then(res => {
            return callback(null, res);
        }).catch(function (err) {
            return callback(err);
        });
};

let getCollectionVideosByVideoId = function (videoId, callback) {
    models.CollectionVideo.findAndCountAll({
        where: {
            VideoId: videoId
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

let deleteCollectionVideosByVideoId = function (videoId, callback) {
    models.CollectionVideo.destroy({
        where: {
            VideoId: videoId
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

module.exports = {
    CreateCollectionVideo: CreateCollectionVideo,
    getCollectionVideosByVideoId: getCollectionVideosByVideoId,
    deleteCollectionVideosByVideoId: deleteCollectionVideosByVideoId
};