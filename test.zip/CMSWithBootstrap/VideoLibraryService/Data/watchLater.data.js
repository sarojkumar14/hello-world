const models = require('../models');

let createWatchLater = function (video, callback) {

    models.WatchLater.count({
        where: {
            VideoId: video.VideoId
        }
    }).then(res => {
        if (res > 0) {
            models.sequelize.query(`UPDATE WatchLater SET CreatedOn=getdate(),IsRemoved='false' WHERE VideoId = ${video.VideoId} `, {
                type: models.sequelize.QueryTypes.UPDATE
            }).then(updateRes => {
                callback(null, updateRes);
            }).catch(function (err) {
                callback(err);
            });
        } else {
            models.WatchLater.create(video)
                .then(res => {
                    callback(null, res);
                }).catch(function (err) {
                    callback(err);
                });
        }
    }).catch(function (err) {
        callback(err);
    });
};

let removeWatchLater = function (watchId, callback) {
    models.sequelize.query(`UPDATE WatchLater SET IsRemoved='true' WHERE WLId = ${watchId}`, {
        type: models.sequelize.QueryTypes.UPDATE
    }).then(updateRes => {
        callback(null, updateRes);
    }).catch(function (err) {
        callback(err);
    });
}

let getWatchLaterByUser = function (userId, callback) {
    models.sequelize.query(` SELECT WLId,wh.VideoId,wh.UserId
      ,wh.CreatedOn,wh.CreatedBy
	  ,vdo.Guid,vdo.FileName
      ,vdo.Title,vdo.StandaloneURL
      ,vdo.EmbededURL,vdo.Description
      ,vdo.ViewCount,vdo.Type
      ,vdo.Path,vdo.Size
      ,vdo.Tags,vdo.Rating
      ,vdo.Privacy,vdo.Owner
      ,vdo.Topic,vdo.Grade,vdo.Unit
    FROM WatchLater wh
    INNER JOIN Video vdo ON vdo.VideoId=wh.VideoId
    WHERE wh.UserId=1
	AND wh.IsRemoved!='true'
    ORDER BY wh.CreatedOn DESC`, {
            type: models.sequelize.QueryTypes.SELECT
        }).then(response => {
            callback(null, response);
        }).catch(function (err) {
            callback(err);
        });
}


module.exports = {
    createWatchLater: createWatchLater,
    getWatchLaterByUser: getWatchLaterByUser,
    removeWatchLater: removeWatchLater
}