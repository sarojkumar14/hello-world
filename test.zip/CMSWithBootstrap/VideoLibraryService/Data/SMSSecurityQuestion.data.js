const models = require('../models');

let getAllSMSSecurityQuestion = function (callback) {
    models.SMSSecurityQuestion.findAndCountAll({
        where: {
            IsActive: 'Y'
        }
    })
        .then(questions => {
            callback(null, questions);
        }).catch(function (err) {
            callback(err);
        });
};

module.exports = {
    getAllSMSSecurityQuestion: getAllSMSSecurityQuestion
};