const models = require('../models');
var Sequelize = require('sequelize');
const Op = Sequelize.Op;

let CreateResource = function (resource, callback) {
    models.Resource.create(resource)
        .then(res => {
            callback(null, res);
        }).catch(function (err) {
            callback(err);
        });
};

let getResourcesByIds = function (resourceIds, callback) {
    models.Resource.findAndCountAll({
        where: {
            [Op.or]: resourceIds
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

let DeleteResource = function (documentId, guid, callback) {
    models.Resource.destroy({
        where: {
            DocumentId: documentId,
            Guid: guid,
        }
    }).then(resData => {
        callback(null, resData);
    }).catch(function (err) {
        callback(err);
    });
};

module.exports = {
    CreateResource: CreateResource,
    getResourcesByIds: getResourcesByIds,
    DeleteResource: DeleteResource
};