const models = require('../models');

let createComment = function (comment, callback) {
    models.Comment.create(comment)
        .then(res => {
            callback(null, res);
        }).catch(function (err) {
            callback(err);
        });
};

let deleteComment = function (commentId, callback) {
    models.Comment.destroy({
            where: {
                CommentId: commentId
            }
        })
        .then(response => {
            models.Comment.destroy({
                    where: {
                        RepliedCommentID: commentId
                    }
                })
                .then(response => {
                    callback(null, response);
                }).catch(function (err) {
                    callback(err);
                });
        }).catch(function (err) {
            callback(err);
        });
}

let getReplyOnComments = function (commentId, callback) {
    models.sequelize.query(`SELECT 
      cmt.CommentId
      ,cmt.UserId
      ,cmt.VideoId
      ,cmt.Comments
	  ,usr.UserName
      ,cmt.CreatedOn
      ,cmt.CreatedBy
      ,cmt.UpdatedOn
      ,cmt.UpdatedBy
  FROM Comment cmt
  INNER JOIN SMSUser usr ON usr.UserId=cmt.UserId
  WHERE cmt.RepliedCommentID=${commentId}
    ORDER BY cmt.CreatedOn DESC`, {
        type: models.sequelize.QueryTypes.SELECT
    }).then(response => {
        callback(null, response);
    }).catch(function (err) {
        callback(err);
    });
}

let getCommentsByVideo = function (videoId, callback) {
    models.sequelize.query(` SELECT cmt.CommentId
      ,cmt.UserId
      ,cmt.VideoId
      ,cmt.Comments
      ,cmt.RepliedCommentID
	  ,usr.UserName
      ,cmt.CreatedOn
      ,cmt.CreatedBy
      ,cmt.UpdatedOn
      ,cmt.UpdatedBy
  FROM Comment cmt
  INNER JOIN SMSUser usr ON usr.UserId=cmt.UserId
  WHERE cmt.VideoId=${videoId}
    ORDER BY cmt.CreatedOn DESC`, {
        type: models.sequelize.QueryTypes.SELECT
    }).then(response => {
        callback(null, response);
    }).catch(function (err) {
        callback(err);
    });
}

updateComment = function (comment, callback) {
    models.Comment.update(comment, {
        where: {
            CommentId: comment.CommentId
        },
        returning: true,
        plain: true
    }).then(result => {
        callback(null, result);
    }).catch(function (err) {
        callback(err, null);
    });
}

module.exports = {
    createComment: createComment,
    getCommentsByVideo: getCommentsByVideo,
    deleteComment: deleteComment,
    getReplyOnComments: getReplyOnComments,
    updateComment: updateComment
}