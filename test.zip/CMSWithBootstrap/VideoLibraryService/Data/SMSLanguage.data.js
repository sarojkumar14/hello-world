const models = require('../models');
var Sequelize = require('sequelize');
const Op = Sequelize.Op;

var getLanguages = function (callback) {
    models.SMSLanguage.findAndCountAll({}).then(res => {
        callback(null, res);
    }).catch(function (err) {
        callback(err);
    });
};

module.exports = {
    getLanguages: getLanguages
};