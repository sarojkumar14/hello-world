const elastic = require('../global/elasticConfig');

let pingHost = function (callback) {
    elastic.client.ping({ requestTimeout: 30000 }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        callback(null, resp);
    })
}

let checkClusterHealth = function (callback) {
    elastic.client.cluster.health({}, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        callback(null, resp);
    });
};

let indexExists = function (indexName, callback) {
    elastic.client.indices.exists({
        index: indexName
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let createIndex = function (indexName, callback) {
    elastic.client.indices.create({
        index: indexName
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let deleteIndex = function (indexName, callback) {
    elastic.client.indices.delete({
        index: indexName
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let addDocumentWithAttachment = function (indexName, _id, docType, payload, callback) {
    elastic.client.index({
        index: indexName,
        type: docType,
        id: _id,
        body: payload,
        pipeline: 'attachment'
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let addDocument = function (indexName, _id, docType, payload, callback) {
    elastic.client.index({
        index: indexName,
        type: docType,
        id: _id,
        body: payload
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let updateDocument = function (index, _id, docType, payload, callback) {
    elastic.client.update({
        index: index,
        type: docType,
        id: _id,
        body: payload
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let deleteDocument = function (index, _id, docType, callback) {
    elastic.client.delete({
        index: index,
        type: docType,
        id: _id,
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
};

let search = function (indexName, docType, payload, callback) {
    elastic.client.search({
        index: indexName,
        type: docType,
        body: payload
    }, function (err, resp, status) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, resp);
        }
    });
}

module.exports = {
    pingHost: pingHost,
    indexExists: indexExists,
    checkClusterHealth: checkClusterHealth,
    createIndex: createIndex,
    deleteIndex: deleteIndex,
    addDocument: addDocument,
    addDocumentWithAttachment: addDocumentWithAttachment,
    updateDocument: updateDocument,
    deleteDocument: deleteDocument,
    search: search
}