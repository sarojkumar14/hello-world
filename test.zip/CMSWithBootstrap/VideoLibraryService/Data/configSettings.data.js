const models = require('../models');

const getConfigSettings = function (callback) {
    models.ConfigurationSettings.findAll()
        .then(settings => {
            callback(null, settings);
        }).catch(function (err) {
            callback(err);
        });
}

const upsert = function (data, callback) {
    models.ConfigurationSettings.count({
        where: {
            ConfigKey: data.ConfigKey
        }
    }).then(res => {
        if (res > 0) {
            models.sequelize.query(`UPDATE configurationSettings SET ConfigValue='${data.ConfigValue}',
            UpdatedOn='${data.UpdatedOn}',UpdatedBy='${data.UpdatedBy}'
            WHERE ConfigKey = '${data.ConfigKey}'`, {
                    type: models.sequelize.QueryTypes.UPDATE
                }).then(updateRes => {
                    callback(null, updateRes);
                }).catch(function (err) {
                    callback(err);
                });
        } else {
            models.ConfigurationSettings.create(data)
                .then(res => {
                    callback(null, res);
                }).catch(function (err) {
                    callback(err);
                });
        }
    }).catch(function (err) {
        callback(err);
    });
}

module.exports = {
    getConfigSettings: getConfigSettings,
    upsert: upsert
}