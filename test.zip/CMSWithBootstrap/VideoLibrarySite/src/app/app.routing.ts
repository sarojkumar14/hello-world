import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './acc_management/login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './_guard/auth.guard';
import { AdminGuard } from './_guard/admin.guard';
import { AdminLandingComponent } from './admin/admin-landing/admin-landing.component';
import { LibraryComponent } from './admin/library/library.component';
import { UploadVideoComponent } from './uploadfile/upload-video/upload-video.component';
import { RegisterComponent } from './acc_management/register/register.component';
import { SearchComponent } from './search/search.component';
import { ForgotPasswordComponent } from './acc_management/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './acc_management/change-password/change-password.component';
import { VideoplayerComponent } from './videoplayer/videoplayer.component';
import { HistoryComponent } from './history/history.component';
import { AddvideosComponent } from './addvideos/addvideos.component';
import { LinkusercollectionvideoComponent } from './linkusercollectionvideo/linkusercollectionvideo.component';
import { WatchlaterComponent } from './watchlater/watchlater.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { SettingsComponent } from './settings/settings.component';
import { ListVideoComponent } from './uploadfile/list-video/list-video.component';
import { EditVideoComponent } from './uploadfile/edit-video/edit-video.component';
import { CollectionComponent } from './collections/collection/collection.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  {
    path: 'admin', component: AdminLandingComponent, canActivateChild: [AuthGuard], canActivate: [AuthGuard], children: [
      { path: 'library', component: LibraryComponent }
    ]
  },
  {
    path: 'videolist', component: ListVideoComponent, canActivate: [AuthGuard]
  },
  {
    path: 'uploadvideo', component: UploadVideoComponent, canActivate: [AuthGuard]
  },
  {
    path: 'editvideo', component: EditVideoComponent, canActivate: [AuthGuard]
  },
  {
    path: 'register', component: RegisterComponent
  },
  { path: 'search', component: SearchComponent, canActivate: [AuthGuard] },
  { path: 'forgotpassword', component: ForgotPasswordComponent },
  { path: 'changepassword', component: ChangePasswordComponent, canActivate: [AuthGuard] },
  {
    path: 'videoplayer', component: VideoplayerComponent
  },
  { path: 'history', component: HistoryComponent, canActivate: [AuthGuard] },
  { path: 'videoplayer/:type/:videoid/:playlistid', component: VideoplayerComponent },
  { path: 'addvideos', component: AddvideosComponent },
  { path: 'linkusercollectionvideo', component: LinkusercollectionvideoComponent },
  { path: 'watchlater', component: WatchlaterComponent, canActivate: [AuthGuard] },
  { path: 'playlist', component: PlaylistComponent, canActivate: [AuthGuard] },
  { path: 'settings', component: SettingsComponent, canActivate: [AuthGuard, AdminGuard] },
  { path: 'collections', component: CollectionComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
