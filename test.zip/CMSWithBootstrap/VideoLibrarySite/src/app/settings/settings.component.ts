import { Component, OnInit } from '@angular/core';

import { AuthService, NotificationService, SettingsService } from '../_services';
import { Serverresponse } from '../_models/serverresponse';
import { Settings } from '../_models';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SettingsKeyConstants } from '../_helpers/setting.enum';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  private token: string = '';
  private config: any;
  private isEditMode: boolean = false;
  private currentUserId: number = 0;
  private form: FormGroup;
  private formSumitAttempt: boolean;

  private keys(): Array<string> {
    var keys = Object.keys(SettingsKeyConstants);
    return keys.slice(keys.length / 2);
  }

  constructor(private authService: AuthService
    , private notification: NotificationService
    , private settingsService: SettingsService
    , private fb: FormBuilder
  ) {
    this.token = this.authService.getCurrentUserAccessToken();
    this.currentUserId = this.authService.currentUserId();

    this.form = this.fb.group({
      Key: [null, Validators.required],
      Value: [null, Validators.required]
    });
  }

  isFieldValid(field: string) {
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSumitAttempt)
    );
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  ngOnInit() {
    this.configSettings();
  }

  ChangeMode() {
    this.isEditMode = this.isEditMode ? false : true;
    // if (this.config != undefined && this.config != null) {
    //   this.form.patchValue({
    //     ElasticHost: this.config.ElasticHost,
    //     ElasticIndex: this.config.ElasticIndex,
    //     MailHost: this.config.MailHost,
    //     MailPassword: this.config.MailPassword,
    //     MailPort: this.config.MailPort,
    //     MailUsername: this.config.MailUsername,
    //     MailSecure: this.config.MailSecure,
    //     ElasticSearchSize: this.config.ElasticSearchSize,
    //     ElasticType: this.config.ElasticType
    //   })
    // }
  }

  reset() {
    this.form.reset();
    this.formSumitAttempt = false;
  }

  findKey(key) {
    if (this.config != null && this.config != undefined) {
      let value = this.config.find(x => x.ConfigKey == key);
      if (value) {
        return true;
      } else {
        return false;
      }
    }
  }

  onSubmit() {
    this.formSumitAttempt = true;
    if (this.form.valid) {
      let settings = new Settings();
      let value = this.findKey(this.form.value.Key);
      if (!value) {
        settings.CreatedBy = this.currentUserId;
        settings.CreatedOn = new Date(Date.now()).toISOString();
      } else {
        settings.UpdatedOn = new Date(Date.now()).toISOString();
        settings.UpdatedBy = this.currentUserId;
      }
      settings.ConfigKey = this.form.value.Key;
      settings.ConfigValue = this.form.value.Value;

      // settings.ElasticHost = this.form.value.ElasticHost;
      // settings.ElasticIndex = this.form.value.ElasticIndex;
      // settings.MailHost = this.form.value.MailHost;
      // settings.MailPassword = this.form.value.MailPassword;
      // settings.MailPort = this.form.value.MailPort;
      // settings.MailUsername = this.form.value.MailUsername;
      // settings.MailSecure = this.form.value.MailSecure;
      // settings.ElasticSearchSize = this.form.value.ElasticSearchSize;
      // settings.ElasticType = this.form.value.ElasticType;

      this.settingsService.upsert(settings, this.token)
        .subscribe(response => {
          this.reset();
          this.isEditMode = false;
          this.notification.showSuccess("Settings saved or updated successfully.");
          this.configSettings();
        },
          err => {
            console.log(err);
            this.notification.showError("An error occured while saving settings.")
          })
    }
  }

  configSettings() {
    this.settingsService.getConfigSettings(this.token)
      .subscribe(response => {
        let res = response as Serverresponse;
        this.config = res.Data;
        console.log(this.config)
        if (this.config == null) {
          this.isEditMode = true;
        }
      }, err => {
        this.notification.showError("An error occured while retriving value");
        console.log(err);
      });
  }
}
