
// Bootstrap Tooltip
$(window).on("load", readyFn);
function readyFn(jQuery) {
    $('[data-toggle="tooltip"]').tooltip();
}

// Sidebar Menu Open Close
$(document).on("click", ".pe-v-menu-exit", function () {
    $('.sidebar').addClass('active');
    $('.dashboard').addClass('active');
});

$(document).on("click", ".pe-v-menu-open", function () {
    $('.sidebar').removeClass('active');
    $('.dashboard').removeClass('active');
});

// Sidebar Submenu Menu Highlight
$(document).on("click", ".pe-v-collection-searchlist li", function () {
    $('.pe-v-collection-searchlist li').removeClass('active');
    $(this).addClass('active');
});

// Sidebar Menu Active DeActive
$(document).on("click", ".sidebar ul li", function () {
    $('.sidebar ul li').removeClass('active');
    $(this).addClass('active');
});

// List View Grid 
$(document).on("click", "#list", function () {
    $(this).addClass('active');
    $('#grid').removeClass('active');
    $('.pe-v-item').addClass('list');
    $('.pe-v-item').removeClass('grid');
});

$(document).on("click", "#grid", function () {
    $(this).addClass('active');
    $('#list').removeClass('active');
    $('.pe-v-item').removeClass('list');
    $('.pe-v-item').addClass('grid');
});

$(document).on("click", ".pe-v-information", function (e) {
    $('.pe-v-drobdown-menu').hide();
    //  $('.pe-v-drobdown-menu').removeClass('show');
    //if ($(e.target).hasClass('pe-v-more-action')) {
    $(this).find('.pe-v-drobdown-menu').toggle();
    //  $(e.currentTarget).find('.pe-v-drobdown-menu').toggle();
    // }
});

// $(document).click(function (e) {
//     console.log(e.target.className);
//     if ($(".pe-v-drobdown-menu").css('display') == "block") {
//         $('.pe-v-drobdown-menu').css('display', 'none');
//     } else if (e.target.className == 'pe-v-information' && e.target.className == 'pe-v-drobdown-menu') {

//     }
// });
