import { Component, OnInit } from '@angular/core';
import { WatchLaterService } from '../_services/later.service';
import { AuthService, NotificationService, HistoryService, DataService } from '../_services';
import { Serverresponse } from '../_models/serverresponse';
import { WatchLater } from '../_models';

@Component({
  selector: 'app-watchlater',
  templateUrl: './watchlater.component.html',
  styleUrls: ['./watchlater.component.css']
})
export class WatchlaterComponent implements OnInit {
  private token: string = "";
  private currentUser: any;
  private watchLater: any = [];
  private filterableCollection: any = [];
  private page: number = 1;
  private pageSize: number = 10;
  private order: string = '';
  private reverse: boolean = false;

  constructor(private watchlaterService: WatchLaterService
    , private authService: AuthService
    , private notification: NotificationService
    , private dataService: DataService) {
    this.token = this.authService.getCurrentUserAccessToken();
    this.currentUser = this.currentUser == undefined
      ? JSON.parse(this.authService.getAuthUserDetail())
      : this.currentUser;
    this.getUserWatchLater();
  }

  getUserWatchLater(): any {
    let userId = this.currentUser.Data.UserId;
    this.watchlaterService.getWatchLaterByUser(userId, this.token)
      .subscribe(response => {
        console.log(response);
        let value = response as Serverresponse;
        this.watchLater = value.Data;
        this.filterableCollection = value.Data;
      },
        err => {
          console.log(err);
          this.notification.showError("An error occured while getting watch later, Try after sometime.")
        })
  }

  ngOnInit() {
  }

  add(event) {
    alert(event);

  }

  remove(event) {
    if (!event.isHistory) {
      this.watchlaterService.removeWatchLater(event.value, this.token)
        .subscribe(response => {
          this.notification.showSuccess("This video removed from watch later successfully.");
          this.getUserWatchLater();
        },
          err => {
            console.log(err);
            this.notification.showError("An error occured while getting watch later, Try after sometime.")
          })
    }
  }

  orderBy(option) {
    if (this.order == option) {
      this.reverse = !this.reverse;
    }
    this.order = option;
  }

  changePaging(page) {
    this.pageSize = page;
  }

  filterCollection(option) {
    this.filterableCollection = this.watchLater.filter(function (node) {
      if (option == "video") {
        return node.Type == "video/mp4";
      } else if (option == "document") {
        console.log(node._source)
        return node.Type != "video/mp4";
      } else {
        return node;
      }
    })
  }

}
