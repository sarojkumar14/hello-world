import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { History, WatchLater } from '../_models';
import { HistoryService, AuthService, NotificationService, FileService, WatchLaterService } from '../_services';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  private watchLater;
  private currentUser: any;
  private watchHistory: History;
  private token: string;

  @Input() file: any;
  @Input() isFromHistory: boolean;
  @Input() isFromWatchLater: boolean;
  @Input() isRemoveFromPlaylist: boolean;
  @Input() isViewPlayer: boolean;

  @Output() removeEvent = new EventEmitter<{ value: number, isHistory: boolean }>();

  constructor(private historyService: HistoryService
    , private authService: AuthService
    , private notification: NotificationService
    , private fileService: FileService
    , private watchlaterService: WatchLaterService
    , private router: Router
    , private activatedRoute: ActivatedRoute) {
    this.currentUser = this.currentUser == undefined
      ? JSON.parse(this.authService.getAuthUserDetail())
      : this.currentUser;
    this.token = this.token == undefined
      ? this.authService.getCurrentUserAccessToken()
      : this.token;
  }

  ngOnInit() {
  }

  getIcon(type) {
    if (type == "video/mp4") {
      return "../../assets/video.png";
    } else {
      return "../../assets/document.png";
    }
  }

  delete(value: number, isHistory) {
    this.removeEvent.emit({ value: value, isHistory: isHistory });
  }

  create(file, isHistory) {
    console.log(file)
    if (file.Type != "video/mp4")
      return;
    if (isHistory) {

      this.watchHistory = new History();
      this.watchHistory.VideoId = file.VideoId;
      this.watchHistory.UserId = this.currentUser.Data.UserId;
      this.watchHistory.IsRemoved = false;
      this.watchHistory.CreatedOn = new Date(Date.now()).toISOString();
      this.watchHistory.WatchedOn = new Date(Date.now()).toISOString();
      this.watchHistory.CreatedBy = this.currentUser.Data.UserId;
      this.historyService.createHistory(this.watchHistory, this.token)
        .subscribe(
          respones => {
            this.fileService.updateViewCount(file.VideoId, this.token)
              .subscribe(
                updateRes => {
                  console.log(updateRes);
                },
                err => {
                  console.log(err);
                  this.notification.showError("An error occured while update count.")
                }
              )
          },
          err => {
            this.notification.showError("An error occured while creating history.")
            console.log(err);
          }
        )
    } else {
      this.watchLater = new WatchLater();
      this.watchLater.VideoId = file.VideoId;
      this.watchLater.UserId = this.currentUser.Data.UserId;
      this.watchLater.IsRemoved = false;
      this.watchLater.CreatedOn = new Date(Date.now()).toISOString();
      this.watchLater.CreatedBy = this.currentUser.Data.UserId;

      this.watchlaterService.create(this.watchLater, this.token)
        .subscribe(
          updateRes => {
            console.log(updateRes);
            this.notification.showSuccess("This video added into watch later successfully.")
          },
          err => {
            console.log(err);
            this.notification.showError("An error occured while add watch later count.")
          }
        )
    }

    let playlistid = file.PlaylistId == undefined ? file.CollectionId : file.PlaylistId;
    let type = file.PlaylistId == undefined ? 'collection' : 'playlist';
    this.router.navigate(['videoplayer', type, file.VideoId, playlistid]);
  }

  edit(file: any) {
    if (file.Type == "video/mp4") {

      this.fileService.tempData = file;
      this.router.navigate(['editvideo']);
    }
    else {
      alert("Please Choose editable file.");
    }
  }
}
