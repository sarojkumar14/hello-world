import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CollectionService, AuthService, PlaylistService, NotificationService } from '../_services/index';
import * as $ from 'jquery';
import { FormControl } from '@angular/forms';
import { CommentService } from '../_services/comment.service';
import { Serverresponse } from '../_models/serverresponse';
import { Comment } from '../_models';
//import * as videojs from "videojs"
declare const videojs: any;
@Component({
  selector: 'app-videoplayer',
  templateUrl: './videoplayer.component.html',
  styleUrls: ['./videoplayer.component.css']
})
export class VideoplayerComponent implements OnInit {


  private videosFromPlaylist: any;
  private playlistName: string;
  private type: string;
  private toggleTranscript: Boolean = false;
  private currentUser: any;
  private videoTranscript: any;
  private currentObj: any;
  private languages: any;
  private lang: any;
  private commentControl = new FormControl();
  private videoId: number;
  private playlistId: number;
  private responseData: any;
  private isSubmitting = false;
  private isDeleting = false;
  private token: any;
  private comments: any[];

  constructor(private _collectionService: CollectionService
    , private _playlistService: PlaylistService
    , private _authService: AuthService
    , private router: Router
    , private activatedRoute: ActivatedRoute
    , private commentService: CommentService
    , private notification: NotificationService) {
    this.languages = [
      { name: "English", type: "en" },
      { name: "Spanish", type: "sp" },
      { name: "Japanese", type: "jp" }
    ]
    this.token = this._authService.getCurrentUserAccessToken();
    const routeparams = this.activatedRoute.snapshot.params;
    this.videoId = routeparams.videoid;
    this.playlistId = routeparams.playlistid;
    this.type = routeparams.type;
    console.log(routeparams)
    console.log(this.videoId);
    this.getComments();
  }

  ngOnInit() {
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    let loggedUserDetail = this.currentUser.Data;
  }

  ngAfterViewInit() {
    this.type == 'playlist' ? this.getPlaylistVideo(this.playlistId) : this.getUserCollectionVideos();
  }

  getPlaylistVideo(data) {
    this._playlistService.getPlaylistVideo(data, this.currentUser.token).subscribe(result => {
      this.responseData = result;
      this.videosFromPlaylist = this.responseData.data;
      this.playlistName = this.videosFromPlaylist[0].PlaylistName;
    })
  }

  getUserCollectionVideos() {
    this._collectionService.getUserCollectionVideos(this.currentUser.token, this.currentUser.Data.UserId, this.currentUser.Data.RoleId, this.playlistId).subscribe((res) => {
      this.responseData = res;
      this.videosFromPlaylist = this.responseData.data;
      this.playlistName = this.videosFromPlaylist[0].CollectionName;
    });
  }

  showTranscript(): any {
    this.toggleTranscript = !this.toggleTranscript;
    this.lang = "en"
    let loggedUserDetail = this.currentUser.Data;
    this._collectionService.readVideoTranscript(this.token, loggedUserDetail.UserId, this.lang).subscribe((result) => {
      this.currentObj = result
      this.videoTranscript = this.currentObj.data;
      $(".transcript-body").css("height", $(".embed-responsive-16by9").outerHeight());
      $(".transcript-body").css("overflow-y", "scroll");
    })
  }

  closeTranscript() {
    this.toggleTranscript = false;
  }

  selectLanguageVideoTranscript(lng) {
    let loggedUserDetail = this.currentUser.Data;
    this._collectionService.readVideoTranscript(this.token, loggedUserDetail.UserId, lng).subscribe((result) => {
      this.currentObj = result
      this.videoTranscript = this.currentObj.data;
      $(".transcript-body").css("height", $(".embed-responsive-16by9").outerHeight());
      $(".transcript-body").css("overflow-y", "scroll");
    })
  }


  selectVideoToPlaylist(videoId) {
    this._collectionService.callCollectionBehaviourSubject(videoId);
  }

  addVideoToPlaylist(videoId) {
    this._playlistService.createPlaylistApi(videoId);
  }

  //comments

  getComments() {
    this.commentService.getVideoComments(this.videoId, this.token)
      .subscribe(
        response => {
          let value = response as Serverresponse;
          this.comments = value.Data;
        },
        err => {
          console.log(err);
          this.notification.showError("An error occured while retrieving comments")
        }
      )
  }

  validation() {
    this.commentControl.reset('');
    this.isSubmitting = false;
    this.notification.showWarning('Comment should not be empty!');
    return;
  }

  addComment() {
    this.isSubmitting = true;
    if (this.commentControl.value == null) {
      return this.validation();
    } else if (this.commentControl.value.trim() == "") {
      return this.validation();
    }

    let comment = new Comment();
    comment.Comments = this.commentControl.value;
    comment.UserId = this._authService.currentUserId();
    comment.CreatedBy = this._authService.currentUserId();
    comment.VideoId = this.videoId;
    comment.CreatedOn = new Date(Date.now()).toISOString();

    this.commentService
      .createComment(comment, this.token)
      .subscribe(
        comment => {
          // this.comments.unshift(comment);
          this.getComments();
          this.commentControl.reset('');
          this.isSubmitting = false;
        },
        errors => {
          this.isSubmitting = false;
        }
      );
  }

  onReply(event) {
    let comment = new Comment();
    comment.Comments = event.reply;
    comment.UserId = this._authService.currentUserId();
    comment.CreatedBy = this._authService.currentUserId();
    comment.VideoId = this.videoId;
    comment.CreatedOn = new Date(Date.now()).toISOString();
    comment.RepliedCommentID = event.replyId;

    this.commentService
      .createComment(comment, this.token)
      .subscribe(
        comment => {
          this.getComments();
        },
        errors => {
          alert("err");
        }
      );
  }

  onDeleteComment(comment) {
    this.commentService
      .deleteComment(comment.CommentId, this.token)
      .subscribe(
        response => {
          this.getComments();
          this.notification.showSuccess("Comment deleted successfully");
        },
        errors => {
          console.log(errors)
        }
      )
  }
}
