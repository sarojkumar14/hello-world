import { Component, OnInit, AfterViewInit, AfterViewChecked, Input, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'
import * as $ from 'jquery'


@Component({
  selector: 'app-videosfromplaylist',
  templateUrl: './videosfromplaylist.component.html',
  styleUrls: ['./videosfromplaylist.component.css']
})
export class VideosfromplaylistComponent implements OnInit {

  @Input() videos: any;
  @Input() name: string;
  @Input() selectedVideoId: string;

  selectedCount: Number;
  routeparams: any;
  constructor(private router: Router
    , private activatedRoute: ActivatedRoute
    , private cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.routeparams = this.activatedRoute.snapshot.params;
  }

  ngAfterViewInit() {

  }

  ngAfterViewChecked() {
    $(".video-preview").removeClass("video-active")

    if (this.videos != undefined) {
      this.selectedCount = (this.videos.map(function (e) { return e.VideoId; }).indexOf(this.selectedVideoId) + 1);
    }
    let selectedvideo = "#" + this.selectedVideoId;
    $(selectedvideo).addClass('video-active');
    this.cd.detectChanges();
  }


  clickVideo(video) {
    this.selectedVideoId = video.VideoId;
    let playlistorcollectionid = video.PlaylistId == undefined ? video.CollectionId : video.PlaylistId;
    this.router.navigate(['videoplayer', this.routeparams.type, video.VideoId, playlistorcollectionid]);
  }
}
