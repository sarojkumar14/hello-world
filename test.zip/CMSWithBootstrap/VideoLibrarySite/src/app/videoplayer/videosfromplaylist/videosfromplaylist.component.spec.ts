import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideosfromplaylistComponent } from './videosfromplaylist.component';

describe('VideosfromplaylistComponent', () => {
  let component: VideosfromplaylistComponent;
  let fixture: ComponentFixture<VideosfromplaylistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideosfromplaylistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideosfromplaylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
