import { Injectable, EventEmitter } from "@angular/core";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from "rxjs/Subject";

@Injectable()
export class DataService {


}