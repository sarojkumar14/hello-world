import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { CollectionModel } from '../_models/collection'
import { CollectionService, AuthService, PlaylistService } from '../_services/index'
import { PlaylistModel } from '../_models/playlist';
@Component({
  selector: 'app-collectionvideo',
  templateUrl: './collectionvideo.component.html',
  styleUrls: ['./collectionvideo.component.css']
})
export class CollectionvideoComponent implements OnInit {

  isGrid: Boolean;
  visibleAddCollection: boolean;
  isAddCollection: boolean;
  collection: CollectionModel;
  isAdmin: boolean;
  selectedCollectionName: String;
  collectionList: any;
  collectionObject: any;
  currentUser: any;
  videoCollectionList: any;
  filterableCollection: any;
  playlist: PlaylistModel;
  filteredCollection: any;

  constructor(private _collectionService: CollectionService, private _authService: AuthService) { }

  ngOnInit() {
    this.selectedCollectionName = "All";
    this.collection = new CollectionModel();
    this.playlist = new PlaylistModel();
    this.visibleAddCollection = false;
    this.isGrid = true;
    this.collection.CollectionId = 0;
    this.isAddCollection = false;
    let token = this._authService.getCurrentUserAccessToken();
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    let currentUserRole = this.currentUser.Data.SMSRole.RoleName
    this.isAdmin = currentUserRole == "Admin" ? true : false;
    this.collection.token = token;
    $(".nav-tabs li").on('click', function () {
      $(".nav-tabs li").removeClass("active");
      $(this).addClass("active");
    })

    this.getCollectionByUserRole();
    this.getUserCollectionVideos();
  }



  displayList(event) {
    event.preventDefault();
    this.isGrid = false;
    this.switchGridList("list");
  }

  displayGrid(event) {
    event.preventDefault();
    this.isGrid = true;
    this.switchGridList("grid");
  }

  switchGridList(type) {
    switch (type) {
      case "list":
        $('#products').removeClass('row');
        $('#products .item').removeClass('grid-group-item col-lg-3');
        $('#products .item').addClass('list-group-item col-lg-12');
        break;
      case "grid":
        $('#products').addClass('row');
        $('#products .item').removeClass('list-group-item col-lg-12');
        $('#products .item').addClass('grid-group-item col-lg-3');
        break;
      default:
        $('#products').addClass('row');
        $('#products .item').removeClass('list-group-item col-lg-12');
        $('#products .item').addClass('grid-group-item col-lg-3');
        break;
    }
  }

  clearCollection() {
    this.collection.CollectionName = null;
    this.collection.Description = null;
  }

  addCollection() {
    this.isAddCollection = true;
    this.collection.CollectionId = 0;
    this.collection.CollectionName = null;
    this.collection.Description = null;
    this.visibleAddCollection = true;
  }

  editCollection(item) {
    this.isAddCollection = false;
    this.visibleAddCollection = true;
    this.collection.CollectionId = item.CollectionId;
    this.collection.CollectionName = item.CollectionName;
    this.collection.Description = item.Description;
  }

  saveCollection() {
    this.collection.CreatedBy = 1;
    this.collection.CreatedOn = new Date(Date.now()).toISOString();
    this.collection.UpdatedBy = 1;
    this.collection.UpdatedOn = new Date(Date.now()).toISOString();
    let data = this.collection;
    if (this.collection.CollectionId == 0) {
      this._collectionService.createCollection(data).subscribe((res) => {
        this.visibleAddCollection = false;
        this.clearCollection();
        this.getCollectionByUserRole();
        this._collectionService.callCollectionBehaviourSubject(res);
      });
    } else {
      this._collectionService.updateCollection(data).subscribe((res) => {
        this.visibleAddCollection = false;
        this.clearCollection();
        this.getCollectionByUserRole();
      });
    }

  }

  cancelCollection() {
    this.visibleAddCollection = false;
  }

  getCollectionByUserRole() {
    this._collectionService.getcollectionbyuserrole(this.collection.token, this.currentUser.Data.UserId, this.currentUser.Data.RoleId).subscribe((res) => {
      this.collectionObject = res;
      this.collectionList = this.collectionObject.data;
      this.filteredCollection = Object.assign([], this.collectionList);
    });
  }

  removeCollectionByAdmin(item) {
    let deleteCollection = confirm("Are you sure want to delete this collection?")
    if (deleteCollection) {
      this.collection.CollectionId = item.CollectionId;
      this._collectionService.removeCollection(this.collection.CollectionId, this.collection.token).subscribe((response) => {
        this.getCollectionByUserRole();
      })
    }
  }


  getUserCollectionVideos() {
    this._collectionService.getUserCollectionVideos(this.currentUser.token, this.currentUser.Data.UserId, this.currentUser.Data.RoleId, this.collection.CollectionId).subscribe((res) => {
      this.collectionObject = res;
      this.videoCollectionList = this.collectionObject.data;
    });
  }

  selectCollectionVideos(item) {
    this.collection.CollectionId = item.CollectionId;
    this.selectedCollectionName = item.CollectionName;
    this.visibleAddCollection = false;
    this.getUserCollectionVideos()
  }

  selectAllCollectionVideos() {
    this.collection.CollectionId = 0;
    this.selectedCollectionName = "All";
    this.visibleAddCollection = false;
    this.getUserCollectionVideos()
  }

  downloadFile(file) {
    console.log(file)
  }

  playlistVideoID(data) {

  }
  addVideoToPlaylist(vid) {

    let collectionVideoObj = {
      CollectionId: vid.CollectionId,
      VideoId: vid.VideoId,
      FromComponent: 'collection'
    }
    this._collectionService.callCollectionBehaviourSubject(collectionVideoObj);
  }

  selectVideoToPlaylist(videoid: Number) {
    this._collectionService.callCollectionBehaviourSubject(videoid);
  }

  filterCollection(value) {
    if (!value) {
      this.filteredCollection = Object.assign([], this.collectionList);
    } //when nothing has typed
    this.filteredCollection = Object.assign([], this.collectionList).filter(
      item => item.CollectionName.toLowerCase().indexOf(value.toLowerCase()) > -1
    )
  }
}
