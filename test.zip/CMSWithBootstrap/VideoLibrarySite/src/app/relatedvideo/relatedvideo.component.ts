import { Component, OnInit, Input } from '@angular/core';
import { ElasticService, AuthService, NotificationService } from '../_services';
import { ElasticModel } from '../_models';
import { ElasticConfig } from '../_helpers';
import { NgxCarousel, NgxCarouselStore } from 'ngx-carousel';

@Component({
  selector: 'app-relatedvideo',
  templateUrl: './relatedvideo.component.html',
  styleUrls: ['./relatedvideo.component.css']
})
export class RelatedvideoComponent implements OnInit {
  @Input() tag: string = "";

  private token: string;
  private relatedVideos: any;
  private carouselTileTwo: NgxCarousel;

  constructor(private elasticService: ElasticService
    , private authService: AuthService
    , private notification: NotificationService) {
    this.token = this.authService.getCurrentUserAccessToken();

  }

  ngAfterViewInit() {
    console.log(this.tag)
    let search = new ElasticModel();
    search.index = ElasticConfig.INDEX;
    search.docType = ElasticConfig.TYPE;

    search.payload = `{
          "size":1000,
          "query":{
            "multi_match":{
              "query":"${this.tag}",
               "type":"most_fields",
               "fields": [ "Tags", "FileName","attachment.content" ]
            }
          }
      }`
    console.log(search)
    this.elasticService.search(search, this.token)
      .subscribe(response => {
        console.log(response)
        this.relatedVideos = response;
      },
        err => {
          this.notification.showError("An error occured while search");
        })
  }

  ngOnInit() {
    this.carouselTileTwo = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 230 },
      speed: 600,
      interval: 3000,
      point: {
        visible: true
      },
      load: 2,
      touch: true
    };

  }

  /* It will be triggered on every slide*/
  onmoveFn(data: NgxCarouselStore) {
  }
}
