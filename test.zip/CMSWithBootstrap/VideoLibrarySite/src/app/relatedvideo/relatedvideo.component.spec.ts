import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedvideoComponent } from './relatedvideo.component';

describe('RelatedvideoComponent', () => {
  let component: RelatedvideoComponent;
  let fixture: ComponentFixture<RelatedvideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelatedvideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatedvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
