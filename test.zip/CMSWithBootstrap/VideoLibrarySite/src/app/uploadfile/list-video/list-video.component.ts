import { Component, OnInit } from '@angular/core';
import { CollectionService, AuthService, PlaylistService } from '../../_services/index'
@Component({
  selector: 'app-list-video',
  templateUrl: './list-video.component.html',
  styleUrls: ['./list-video.component.css']
})
export class ListVideoComponent implements OnInit {
  token: any;
  currentUser: any;
  currentUserData: any;
  responseData: any;
  videosList: any;

  constructor(private _authService: AuthService
    , private _collectionService: CollectionService) { }

  ngOnInit() {
    this.token = this._authService.getCurrentUserAccessToken();
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    this.currentUserData = this.currentUser.Data;

    this._collectionService.getAllVideos(this.token, this.currentUserData.RoleId).subscribe((res) => {
      this.responseData = res;
      this.videosList = this.responseData.data;
    })
  }

}
