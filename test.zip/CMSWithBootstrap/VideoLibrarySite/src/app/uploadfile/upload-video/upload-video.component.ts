import { Component, OnInit } from '@angular/core';
import { Video, Transcript, ElasticModel } from '../../_models/index';
import { FileService, AuthService } from '../../_services/index';
import { Router } from '@angular/router';
import { Serverresponse } from '../../_models/serverresponse';
import { NotificationService, ElasticService } from '../../_services/index';
import { ElasticConfig } from '../../_helpers';
import { validateConfig } from '@angular/router/src/config';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-upload-video',
  templateUrl: './upload-video.component.html',
  styleUrls: ['./upload-video.component.css'],
})
export class UploadVideoComponent implements OnInit {

  private token: string = '';
  private video;
  private transcript;
  private resources = {
    ResourcesFiles: []
  };
  private tags = [];
  private collections = [];
  private collectionsDropdownSettings = {};
  private topics = [{ key: 1, value: "Topic 1" }, { key: 2, value: "Topic 2" }, { key: 3, value: "Topic 3" }];
  private grades = [
    { key: 1, value: "Grade 1" }, { key: 2, value: "Grade 2" }, { key: 3, value: "Grade 3" },
    { key: 1, value: "Grade 4" }, { key: 2, value: "Grade 5" }, { key: 3, value: "Grade 6" },
    { key: 1, value: "Grade 7" }, { key: 2, value: "Grade 8" }, { key: 3, value: "Grade 9" },
    { key: 1, value: "Grade 10" }, { key: 2, value: "Grade 11" }, { key: 3, value: "Grade 12" },
  ];

  constructor(private fileService: FileService
    , private authService: AuthService
    , private router: Router
    , private notification: NotificationService
    , private elasticService: ElasticService
    , private loader: Ng4LoadingSpinnerService) {
    this.token = this.authService.getCurrentUserAccessToken();

    this.video = new Video();
    this.video.selectedCollections = [];
    this.video.Ratings = 4;
    // this.video.UpdatedOn = new Date(Date.now()).toISOString();
    //this.video.UpdatedBy = 1;
    this.video.CreatedOn = new Date(Date.now()).toISOString();
    this.video.CreatedBy = 1;
    this.video.VideoFileOrUrlOption = "file";

    this.transcript = new Transcript();
    //this.transcript.UpdatedOn = new Date(Date.now()).toISOString();
    //this.transcript.UpdatedBy = 1;
    this.transcript.CreatedOn = new Date(Date.now()).toISOString();
    this.transcript.CreatedBy = 1;
    this.collectionsDropdownSettings = {
      singleSelection: false,
      text: "Select Collections",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
  }

  ngOnInit() {
    this.getUserCollections();
  }

  getUserCollections(): void {
    this.fileService.getUserCollections(this.token)
      .subscribe(res => {
        var value = res as Serverresponse;
        let c: number = 0;
        if (value.IsSuccess) {
          for (c = 0; c < value.Data.length; c++) {
            this.collections.push({ "id": value.Data[c].CollectionId, "itemName": value.Data[c].CollectionName });
          }
        }
      });
  }

  onFileOrUrlOptionsChange() {
    this.video.EmbededURL = null;
    this.video.StandaloneURL = null;
  }

  onFileChange(event, uploadVideoForm) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      uploadVideoForm.form.controls['file'].setErrors(null);
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.video.FileName = file.name,
          this.video.FileType = file.type,
          this.video.Type = file.type;
        this.video.Size = file.size,
          this.video.FileData = reader.result.split(',')[1],
          this.video.ActualFileName = file.name
      };
    } else {
      uploadVideoForm.form.controls['file'].setErrors({ required: true });
    }
  }

  ontranscriptFileChange(event, uploadVideoForm) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      //uploadVideoForm.form.controls['transcriptFile'].setErrors(null);
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.transcript.FileName = file.name,
          this.transcript.FileType = file.type,
          this.transcript.Size = file.size,
          this.transcript.FileData = reader.result.split(',')[1],
          this.transcript.ActualFileName = file.name
      };
    }
    // else {
    //   uploadVideoForm.form.controls['transcriptFile'].setErrors({ required: true });
    // }
  }

  onResourcesFilesChange(event, uploadVideoForm) {
    this.resources.ResourcesFiles = [];
    var resources = this.resources;
    if (event.target.files && event.target.files.length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        (function (file) {
          var name = file.name;
          var reader = new FileReader();
          reader.onload = () => {
            resources.ResourcesFiles.push({
              FileName: file.name, FileType: file.type,
              Size: file.size, FileData: reader.result.split(',')[1],
              ActualFileName: file.name
            });
          }
          reader.readAsDataURL(file);
        })(event.target.files[i]);
      }
      this.resources = resources;
    }
  }

  onResourceDelete(index: any, resource: any) {
    if (index !== -1) {
      this.resources.ResourcesFiles.splice(index, 1);
    }
  }

  onKey(EmbededURL: any, StandaloneURL: any, uploadVideoForm: any) {

    if (EmbededURL.value || StandaloneURL.value) {
      uploadVideoForm.form.controls['EmbededURL'].setErrors(null);
      uploadVideoForm.form.controls['StandaloneURL'].setErrors(null);
    }
    else {
      uploadVideoForm.form.controls['EmbededURL'].setErrors({ required: true });
      uploadVideoForm.form.controls['StandaloneURL'].setErrors({ required: true });
    }
  }

  onSubmit() {
    this.loader.show();
    this.video.Tags = '';
    if (this.tags.length > 0) {
      for (let tag in this.tags) {
        this.video.Tags += this.tags[tag].value + ','
      }
      this.video.Tags = this.video.Tags.substring(0, this.video.Tags.length - 1);
    }
    if ((this.video.StandaloneURL || this.video.EmbededURL) && !this.video.FileData) {
      this.video.FileName = null,
        this.video.FileType = null,
        this.video.Type = null,
        this.video.Size = null,
        this.video.FileData = null,
        this.video.ActualFileName = null;
    }
    this.fileService.UploadVideo(this.video, this.transcript, this.resources, this.token)
      .subscribe(response => {
        this.loader.hide();
        this.notification.showSuccess("Video Uploaded successsfully.", "Upload Video.");
        this.router.navigate(['videolist']);
        // let value = response as Serverresponse;
        // let videoResponse = value.Data.video;
        // let elasticModel = new ElasticModel();
        // elasticModel._id = videoResponse.Guid;
        // elasticModel.docType = ElasticConfig.TYPE;
        // elasticModel.index = ElasticConfig.INDEX;
        // elasticModel.payload = videoResponse;
        // elasticModel.isHavingAttachement = false;
        // this.elasticService.addDocument(elasticModel, this.token)
        //   .subscribe(res => {
        // this.notification.showSuccess("Video Uploaded successsfully.", "Upload Video.");
        //     this.router.navigate(['../home']);
        //   },
        //   err => {
        //     this.notification.showError(`Error while updating to es ${err.error.Message}`);
        //   })
      },
      err => {
        this.loader.hide();
        this.notification.showError(err.error.Message);
      });
  }
  onCancel() {
    this.router.navigate(['videolist']);
  }

}