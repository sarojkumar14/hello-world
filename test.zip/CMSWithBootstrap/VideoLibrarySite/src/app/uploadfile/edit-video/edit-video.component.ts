import { Component, OnInit } from '@angular/core';
import { Video, Transcript, ElasticModel } from '../../_models/index';
import { FileService, AuthService } from '../../_services/index';
import { Router } from '@angular/router';
import { Serverresponse } from '../../_models/serverresponse';
import { NotificationService, ElasticService } from '../../_services/index';
import { ElasticConfig } from '../../_helpers';
import { validateConfig } from '@angular/router/src/config';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-edit-video',
  templateUrl: './edit-video.component.html',
  styleUrls: ['./edit-video.component.css']
})
export class EditVideoComponent implements OnInit {

  private token: string = '';
  private video;
  private tempData;     //editable video information 
  private videoInformations: any; //it will hold video , transcript , collection video, resource information
  private transcript;
  private resources = {
    ResourcesFiles: []
  };
  private tags = [];
  private collections = [];
  private collectionsDropdownSettings = {};
  private topics = [{ key: 1, value: "Topic 1" }, { key: 2, value: "Topic 2" }, { key: 3, value: "Topic 3" }];
  private grades = [
    { key: 1, value: "Grade 1" }, { key: 2, value: "Grade 2" }, { key: 3, value: "Grade 3" },
    { key: 1, value: "Grade 4" }, { key: 2, value: "Grade 5" }, { key: 3, value: "Grade 6" },
    { key: 1, value: "Grade 7" }, { key: 2, value: "Grade 8" }, { key: 3, value: "Grade 9" },
    { key: 1, value: "Grade 10" }, { key: 2, value: "Grade 11" }, { key: 3, value: "Grade 12" },
  ];
  private isNewVideoFile: boolean = false;
  private isNewTranscriptFile: boolean = false;

  constructor(private fileService: FileService
    , private authService: AuthService
    , private router: Router
    , private notification: NotificationService
    , private elasticService: ElasticService
    , private loader: Ng4LoadingSpinnerService) {
    this.token = this.authService.getCurrentUserAccessToken();

    this.video = new Video();
    this.video.UpdatedOn = new Date(Date.now()).toISOString();
    this.video.UpdatedBy = 1
    this.tempData = this.fileService.tempData;

    if (this.tempData == null || this.tempData.Guid == null || this.tempData.Guid == 'undefined') {
      this.router.navigate(['home']);
      return;
    }
    this.video.Guid = this.tempData.Guid;
    this.video.Title = this.tempData.Title;
    this.video.Description = this.tempData.Description;
    this.video.StandaloneURL = this.tempData.StandaloneURL;
    this.video.EmbededURL = this.tempData.EmbededURL;
    this.video.Type = this.tempData.Type;
    this.video.Path = this.tempData.Path;
    this.video.Size = this.tempData.Size;
    if (this.tempData.FileName == null) {
      this.video.VideoFileOrUrlOption = "url";
    }
    else {
      this.video.VideoFileOrUrlOption = "file";
      this.video.FileName = this.tempData.FileName;
    }

    this.video.Topic = this.tempData.Topic;
    this.video.Grade = this.tempData.Grade;
    this.video.Unit = this.tempData.Unit;

    var tagArray = this.tempData.Tags.split(',');
    if (tagArray != "") {
      for (var a in tagArray) {
        this.tags.push({ display: tagArray[a], value: tagArray[a] });
      }
    }

    this.video.selectedCollections = [];
    this.transcript = new Transcript();
    this.transcript.UpdatedOn = new Date(Date.now()).toISOString();
    this.transcript.UpdatedBy = 1;

    this.collectionsDropdownSettings = {
      singleSelection: false,
      text: "Select Collections",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
  }

  ngOnInit() {
    this.getUserCollections();
    var self = this;
    this.getVideoById(this.video.Guid, function (error, response) {
      if (error) {
        self.notification.showError(error.error.Error.Message);
        self.router.navigate(['videolist']);
        return;
      }
      else {
        self.videoInformations = JSON.parse(JSON.stringify(response));

        //set video file
        self.video.VideoId = response.Data.video.VideoId;
        self.video.FileName = response.Data.video.FileName;
        self.video.FileType = response.Data.video.FileType;
        self.video.Type = response.Data.video.FileType;
        self.video.Size = response.Data.video.Size;
        self.video.FileData = response.Data.videoFileData;

        //set transsript file
        if (response.Data.transcriptFileData) {
          self.transcript.VideoId = response.Data.video.VideoId;
          self.transcript.TranscriptId = response.Data.transcript.TranscriptId;
          self.transcript.Guid = response.Data.transcript.Guid;
          self.transcript.FileName = response.Data.transcript.FileName;
          self.transcript.FileType = response.Data.transcript.FileType;
          self.transcript.Type = response.Data.transcript.FileType;
          self.transcript.Size = response.Data.transcript.Size;
          self.transcript.FileData = response.Data.transcriptFileData;
        }

        //set resource files
        if (response.Data.resourcesFileData) {
          for (let r = 0; r < response.Data.resource.length; r++) {
            self.resources.ResourcesFiles.push({
              DocumentId: response.Data.resource[r].DocumentId,
              Guid: response.Data.resource[r].Guid,
              FileName: response.Data.resource[r].FileName,
              FileType: response.Data.resource[r].Type,
              Size: response.Data.resource[r].Size,
              FileData: response.Data.resourcesFileData[r].FileData
            });
          }
        }

        //set selected collection
        for (let c = 0; c < self.collections.length; c++) {
          for (let s = 0; s < response.Data.collectionVideos.length; s++) {
            if (self.collections[c].id == response.Data.collectionVideos[s].CollectionId) {
              self.video.selectedCollections.push({ "id": self.collections[c].id, "itemName": self.collections[c].itemName });
            }
          }
        }
      }
    });
  }

  getUserCollections(): void {
    this.fileService.getUserCollections(this.token)
      .subscribe(res => {
        var value = res as Serverresponse;
        let c: number = 0;
        if (value.IsSuccess) {
          for (c = 0; c < value.Data.length; c++) {
            this.collections.push({ "id": value.Data[c].CollectionId, "itemName": value.Data[c].CollectionName });
          }
        }
      },
      err => {
        alert(err);
      });
  }

  getVideoById(guid: string, callback): any {
    this.fileService.getVideoById(guid, this.token)
      .subscribe(res => {
        var value = res as Serverresponse;
        return callback(null, value);
      },
      err => {
        return callback(err, null);
      });
  };

  onFileOrUrlOptionsChange() {
    this.video.EmbededURL = null;
    this.video.StandaloneURL = null;
  }

  onFileChange(event, uploadVideoForm) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      //uploadVideoForm.form.controls['file'].setErrors(null);
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.video.FileName = file.name,
          this.video.FileType = file.type,
          this.video.Type = file.type;
        this.video.Size = file.size,
          this.video.FileData = reader.result.split(',')[1],
          this.video.ActualFileName = file.name
      };
      if (this.videoInformations.Data.video.FileName == file.name && this.videoInformations.Data.video.Type == file.type
        && this.videoInformations.Data.video.Size == file.size) {
        this.isNewVideoFile = false;
        alert('This file already you used.');
      }
      else {

        this.isNewVideoFile = true;
      }
    } else {
      //uploadVideoForm.form.controls['file'].setErrors({ required: true });
    }
  }

  updateVideoFile() {
    if (this.isNewVideoFile) {
      this.loader.show();
      this.fileService.UpdateVideoFile(this.videoInformations.Data.video, this.video, this.token)
        .subscribe(response => {
          this.loader.hide();
          this.notification.showSuccess("Video File updated successsfully.", "Update video file.");
          //set video file
          this.videoInformations.Data.video.FileName = this.video.FileName;
          this.videoInformations.Data.video.FileType = this.video.FileType;
          this.videoInformations.Data.video.Size = this.video.Size;
          this.videoInformations.Data.videoFileData = this.video.FileData;
          this.isNewVideoFile = false;
        },
        err => {
          this.loader.hide();
          this.notification.showError(err.error.Message);
        });
    } else {
      alert('Please choose new video file.');
    }
  }

  ontranscriptFileChange(event, uploadVideoForm) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      //uploadVideoForm.form.controls['transcriptFile'].setErrors(null);
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.transcript.FileName = file.name,
          this.transcript.FileType = file.type,
          this.transcript.Size = file.size,
          this.transcript.FileData = reader.result.split(',')[1],
          this.transcript.ActualFileName = file.name
      };
      if (this.videoInformations.Data.transcript) {
        if (this.videoInformations.Data.transcript.FileName == file.name && this.videoInformations.Data.transcript.Size == file.size) {
          this.isNewTranscriptFile = false;
          alert('This file already you used.');
        }
        else {
          this.isNewTranscriptFile = true;
        }
      }
      else {
        this.isNewTranscriptFile = true;
      }

    }
    // else {
    //   uploadVideoForm.form.controls['transcriptFile'].setErrors({ required: true });
    // }
  }

  updateTranscriptFile() {
    if (this.isNewTranscriptFile) {
      this.transcript.VideoId = this.video.VideoId;
      this.transcript.CreatedOn = new Date(Date.now()).toISOString();
      this.transcript.CreatedBy = 1;
      this.loader.show();
      this.fileService.UpdateTranscriptFile(this.videoInformations.Data.transcript, this.transcript, this.token)
        .subscribe(response => {
          this.loader.hide();
          this.notification.showSuccess("Transcript file updated successsfully.", "Update transcript file.");
          //set transcript file
          this.videoInformations.Data.transcript.FileName = this.transcript.FileName;
          this.videoInformations.Data.transcript.FileType = this.transcript.FileType;
          this.videoInformations.Data.transcript.Size = this.transcript.Size;
          this.videoInformations.Data.transcriptFileData = this.transcript.FileData;
          this.isNewTranscriptFile = false;
        },
        err => {
          this.loader.hide();
          this.notification.showError(err.error.Message);
        });
    } else {
      alert('Please choose new video file.');
    }
  }

  onResourcesFilesChange(event, uploadVideoForm) {
    //this.resources.ResourcesFiles = [];
    var resources = this.resources;
    if (event.target.files && event.target.files.length > 0) {
      for (var i = 0; i < event.target.files.length; i++) {
        (function (file) {
          let isResourcePresent = false;
          for (let res = 0; res < resources.ResourcesFiles.length; res++) {
            if (resources.ResourcesFiles[res].FileName == file.name && resources.ResourcesFiles[res].FileType == file.type
              && resources.ResourcesFiles[res].Size == file.size) {
              isResourcePresent = true;
              break;
            }
          }
          if (!isResourcePresent) {
            var name = file.name;
            var reader = new FileReader();
            reader.onload = () => {
              resources.ResourcesFiles.push({
                FileName: file.name, FileType: file.type,
                Size: file.size, FileData: reader.result.split(',')[1],
                ActualFileName: file.name
              });
            }
            reader.readAsDataURL(file);
          }
        })(event.target.files[i]);
      }
      this.resources = resources;
    }
  }

  onResourceDelete(index: any, resource: any) {
    if (index !== -1) {
      if (resource.Guid) {
        this.loader.show();
        this.fileService.DeleteResourceFile(this.videoInformations.Data.video.VideoId, resource, this.token)
          .subscribe(response => {
            this.loader.hide();
            this.notification.showSuccess("Resource file Deleted successsfully.", "Delete resource file.");
            //set resource file
            this.resources.ResourcesFiles.splice(index, 1);
          },
          err => {
            this.loader.hide();
            this.notification.showError(err.error.Message);
          });
      }
      else {
        this.resources.ResourcesFiles.splice(index, 1);
      }
    }
  }

  updateResourceFile(index: any, resource: any) {
    if (index !== -1) {
      if (!resource.Guid) {
        resource.CreatedOn = new Date(Date.now()).toISOString();
        resource.CreatedBy = 1;
        this.loader.show();
        this.fileService.CreateResourceFileForVideo(this.video.VideoId, resource, this.token)
          .subscribe(response => {
            let res = response as any;
            this.loader.hide();
            this.notification.showSuccess("Resource file updated successsfully.", "Update resource file.");
            resource.Guid = res.Data.Guid;
          },
          err => {
            this.loader.hide();
            this.notification.showError(err.error.Message);
          });
      }
    }
  }

  onKey(EmbededURL: any, StandaloneURL: any, uploadVideoForm: any) {

    if (EmbededURL.value || StandaloneURL.value) {
      uploadVideoForm.form.controls['EmbededURL'].setErrors(null);
      uploadVideoForm.form.controls['StandaloneURL'].setErrors(null);
    }
    else {
      uploadVideoForm.form.controls['EmbededURL'].setErrors({ required: true });
      uploadVideoForm.form.controls['StandaloneURL'].setErrors({ required: true });
    }
  }

  onSubmit() {
    this.loader.show();
    this.video.Tags = '';
    if (this.tags.length > 0) {
      for (let tag in this.tags) {
        this.video.Tags += this.tags[tag].value + ','
      }
      this.video.Tags = this.video.Tags.substring(0, this.video.Tags.length - 1);
    }
    if ((this.video.StandaloneURL || this.video.EmbededURL) && !this.video.FileData) {
      this.video.FileName = null,
        this.video.FileType = null,
        this.video.Type = null,
        this.video.Size = null,
        this.video.FileData = null,
        this.video.ActualFileName = null;
    }
    this.fileService.UpdateVideoMetadata(this.video, this.token)
      .subscribe(response => {
        this.loader.hide();
        this.notification.showSuccess("Video edited successsfully.", "Edit Video.");
        this.router.navigate(['videolist']);
      },
      err => {
        this.loader.hide();
        this.notification.showError(err.error.Message);
      });
  }
  onCancel() {
    this.router.navigate(['home']);
  }
}
