import { Component, OnDestroy } from '@angular/core';
import { AuthService, DataService, PlaylistService, CollectionService } from './_services/index';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import "rxjs/add/operator/takeWhile";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isLoggedIn$: boolean;
  user: any;
  currentUser: any;
  currentUserData: any;
  responseData: any;
  playlistCounter: Number = 0;
  collectionCounter: Number = 0;
  private alive: boolean = true;
  private collectionalive: boolean = true;
  constructor(private authService: AuthService, private playlistService: PlaylistService
    , private collectionService: CollectionService
    , private router: Router) {

  }

  ngOnInit() {
    this.authService.isLoggedIn.subscribe(val => {
      this.isLoggedIn$ = val;
      if (!val) {

        this.router.navigate(['']);
        return;
      }

      this.user = JSON.parse(this.authService.getAuthUserDetail());
      this.currentUserData = this.user.Data;
      this.getPlaylistCounter();
      this.getCollectionCounter()
    });
  }

  ngOnDestroy() {
    this.alive = false;
    this.collectionalive = false;
  }

  getPlaylistCounter() {
    let modelObj = {
      UserId: this.currentUserData.UserId,
      token: this.user.token
    }
    this.playlistService.apiCreateData$
      .subscribe(data => {
        this.playlistService.playlistCountByUser(modelObj)
          .takeWhile(() => this.alive)
          .subscribe((result) => {
            this.responseData = result;
            this.playlistCounter = this.responseData.data
          });
      });
  }

  getCollectionCounter() {
    let modelObj = {
      UserId: this.currentUserData.UserId,
      token: this.user.token,
      RoleId: this.currentUserData.RoleId
    }
    this.collectionService.apiData$
      .subscribe(data => {
        this.collectionService.getCollectionCount(modelObj)
          .takeWhile(() => this.collectionalive)
          .subscribe((result) => {
            this.responseData = result;
            console.log(this.responseData)
            this.collectionCounter = this.responseData.data;
          });
      });
  }

  onSearchSubmit(searchForm) {
    if (searchForm.valid) {
      this.router.navigate(['search', searchForm.value]);
    }
  }

  logout() {
    this.authService.logout();
  }
}
