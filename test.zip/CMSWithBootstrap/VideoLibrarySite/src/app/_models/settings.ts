export class Settings {
    ConfigKey: string;
    ConfigValue: string;
    CreatedOn: string;
    CreatedBy: number;
    UpdatedOn: string;
    UpdatedBy: number;
}