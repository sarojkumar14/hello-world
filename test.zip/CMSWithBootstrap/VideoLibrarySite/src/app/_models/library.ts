export class Library {
  id: number;
  name: string;
  description: string;
  image: object;
  token: any;
}
