export class Serverresponse{
    IsSuccess:boolean;
    Data:any;
    Message:string;
    Error:any;
}