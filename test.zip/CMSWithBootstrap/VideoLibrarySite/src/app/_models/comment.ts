export class Comment {
    CommentId: string;
    UserId: string;
    VideoId: number;
    ResourceId: string;
    Comments: string;
    RepliedCommentID: string;
    CreatedOn: string;
    CreatedBy: string;
    UpdatedOn: string;
    UpdatedBy: string;
}