export class PlaylistModel {
    PlaylistId: Number;
    Title: String;
    Description: String;
    UserId: Number;
    CreatedOn: String;
    CreatedBy: Number;
    UpdatedOn: String;
    UpdatedBy: Number;
    token: String;
}