export class WatchLater {
    WLId: number;
    VideoId: number;
    UserId: number;
    IsRemoved: boolean;
    CreatedBy: number;
    CreatedOn: string;
}