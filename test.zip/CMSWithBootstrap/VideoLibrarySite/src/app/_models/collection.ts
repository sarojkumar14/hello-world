export class CollectionModel {
    CollectionId: Number;
    CollectionName: String;
    Description: String;
    CreatedOn: String;
    CreatedBy: Number;
    UpdatedOn: String;
    UpdatedBy: Number;
    token: String;
}