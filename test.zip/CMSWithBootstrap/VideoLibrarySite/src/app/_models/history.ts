export class History {
    WatchId: number;
    VideoId: number;
    UserId: number;
    IsRemoved: boolean;
    WatchedOn: string;
    CreatedBy: number;
    CreatedOn: string;
}