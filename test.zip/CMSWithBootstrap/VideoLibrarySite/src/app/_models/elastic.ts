export class ElasticModel {
    payload: any;
    index: string;
    docType: string;
    _id: string;
    isHavingAttachement: boolean;
}