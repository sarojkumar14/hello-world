import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkusercollectionvideoComponent } from './linkusercollectionvideo.component';

describe('LinkusercollectionvideoComponent', () => {
  let component: LinkusercollectionvideoComponent;
  let fixture: ComponentFixture<LinkusercollectionvideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkusercollectionvideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkusercollectionvideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
