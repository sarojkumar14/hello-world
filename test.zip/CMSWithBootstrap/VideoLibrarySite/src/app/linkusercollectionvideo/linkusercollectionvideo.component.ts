import { Component, OnInit } from '@angular/core';
import { CollectionService, AuthService } from '../_services/index'
@Component({
  selector: 'app-linkusercollectionvideo',
  templateUrl: './linkusercollectionvideo.component.html',
  styleUrls: ['./linkusercollectionvideo.component.css']
})
export class LinkusercollectionvideoComponent implements OnInit {

  constructor(private _collectionService: CollectionService, private _authService: AuthService) { }

  token: any;
  currentUser: any;
  currentUserData: any;
  dataresult: any;
  usersList: any;
  collectionList: any;
  selectUserId: Number;
  ngOnInit() {
    this.selectUserId = 0;
    this.token = this._authService.getCurrentUserAccessToken();
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    this.currentUserData = this.currentUser.Data;

    this._collectionService.getAllUsers(this.token, this.currentUserData.RoleId).subscribe((res) => {
      this.dataresult = res;
      console.log(this.dataresult.data)
      this.usersList = this.dataresult.data;
    })

    this._collectionService.getcollectionbyuserrole(this.token, this.currentUserData.UserId, this.currentUserData.RoleId).subscribe((result) => {
      this.dataresult = result;
      this.collectionList = this.dataresult.data;
    })
  }

  selectUser(item) {
    this.selectUserId = item.UserId;
  }

  linkCollectionToUser(collection) {
    console.log(collection);
    let objUser = {
      token: this.token,
      CollectionId: collection.CollectionId,
      UserId: this.selectUserId,
      CreatedOn: new Date(Date.now()).toISOString(),
      CreatedBy: 1,
      UpdatedOn: new Date(Date.now()).toISOString(),
      UpdatedBy: 1
    }
    this._collectionService.adminLinkCollectionToUser(objUser).subscribe((result) => {
      this.dataresult = result;
      console.log(result);
      //this.collectionList = this.dataresult.data;
    })
  }
}
