import { Component, OnInit } from '@angular/core';
import { HistoryService, AuthService, NotificationService, FileService } from '../_services';
import { Serverresponse } from '../_models/serverresponse';
import { History } from '../_models';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {

  private token: string;
  private currentUser: any;
  private watchedHistory: any = [];
  private filterableCollection: any = [];
  private page: number = 1;
  private pageSize: number = 10;
  private order: string = '';
  private reverse: boolean = false;
  private watchHistory: History;

  constructor(private historyService: HistoryService
    , private authService: AuthService
    , private notification: NotificationService
    , private fileService: FileService) {
    this.token = this.authService.getCurrentUserAccessToken();
    this.currentUser = this.currentUser == undefined
      ? JSON.parse(this.authService.getAuthUserDetail())
      : this.currentUser;
    this.getUserWatchdHistory();
  }

  getUserWatchdHistory() {
    let userId = this.currentUser.Data.UserId;
    this.historyService.getWatchedHistoryByUser(userId, this.token)
      .subscribe(response => {
        console.log(response);
        let value = response as Serverresponse;
        this.watchedHistory = value.Data;
        this.filterableCollection = value.Data;
      },
        err => {
          console.log(err);
          this.notification.showError("An error occured while getting watched history, Try after sometime.")
        })
  }
  add(event: number) {

  }

  remove(event) {
    if (event.isHistory) {
      this.historyService.removeHistory(event.value, this.token)
        .subscribe(res => {
          this.getUserWatchdHistory();
          this.notification.showSuccess("Video from watched history is removed successfully.");
        },
          err => {
            this.notification.showError("An error occured while deleting history, Try after sometime.")
          })
    }
  }

  ngOnInit() {

  }

  orderBy(option) {
    if (this.order == option) {
      this.reverse = !this.reverse;
    }
    this.order = option;
  }

  changePaging(page) {
    this.pageSize = page;
  }

  filterCollection(option) {
    this.filterableCollection = this.watchedHistory.filter(function (node) {
      if (option == "video") {
        return node.Type == "video/mp4";
      } else if (option == "document") {
        console.log(node._source)
        return node.Type != "video/mp4";
      } else {
        return node;
      }
    })
  }

}
