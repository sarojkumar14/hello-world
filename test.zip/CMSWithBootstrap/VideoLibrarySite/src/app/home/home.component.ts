import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { CollectionModel } from '../_models/collection'
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, PlaylistService } from '../_services/index'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private _authService: AuthService,
    private _playlistService: PlaylistService,
    private router: Router, private activatedRoute: ActivatedRoute) {
    _playlistService.apiData$.subscribe(data => this.playlistCounter = data)
  }

  responseData: any;
  playlistCounter: number;
  currentUser: any;
  isAdmin: boolean;


  ngOnInit() {
    let token = this._authService.getCurrentUserAccessToken();
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    let currentUserRole = this.currentUser.Data.SMSRole.RoleName
    this.isAdmin = currentUserRole == "Admin" ? true : false;
  }

  getUserPlaylistCount() {
    let playlist = {
      UserId: this.currentUser.Data.UserId,
      token: this.currentUser.token
    }
    this._playlistService.playlistCountByUser(playlist).subscribe((result) => {
      console.log(result);
      this.responseData = result;
      this.playlistCounter = this.responseData.data;
    })
  }

}
