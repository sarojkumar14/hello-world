import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { AuthService } from '../_services';

@Component({
  selector: 'app-video-comment',
  templateUrl: './video-comment.component.html',
  styleUrls: ['./video-comment.component.css']
})
export class VideoCommentComponent implements OnInit {

  @Input() comment: any;
  @Output() deleteComment = new EventEmitter<boolean>();
  @Output() replyCommentEvent = new EventEmitter<any>();

  private canModify: boolean;

  constructor(private authService: AuthService) {

  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    if (this.comment.UserId == this.authService.currentUserId()) {
      this.canModify == true;
    }
  }

  deleteClicked() {
    this.deleteComment.emit(true);
  }

  replyComment(reply, commentId) {
    if (reply.valid) {
      this.replyCommentEvent.emit({ "reply": reply.value.reply, "replyId": commentId })
    }
  }
}
