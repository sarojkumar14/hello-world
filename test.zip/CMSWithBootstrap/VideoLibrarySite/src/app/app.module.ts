//angular modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//third party modules
import { TagInputModule } from 'ngx-chips';
import { ToastrModule } from 'ngx-toastr';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { NgxCarouselModule } from 'ngx-carousel';
import 'hammerjs';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { TimeAgoPipe } from 'time-ago-pipe';

//gaurds
import { AuthGuard } from './_guard/auth.guard';
import { AdminGuard } from './_guard/admin.guard';

//routing
import { AppRoutingModule } from './app.routing';

//_services
import {
  AuthService
  , LibraryService
  , FileService
  , ElasticService
  , NotificationService
  , CollectionService
  , DataService
  , HistoryService
  , PlaylistService
  , WatchLaterService
  , SettingsService
  , CommentService
} from './_services/index';

//_directive
import { EqualValidator } from './_directive';

//_pipes
import { FilterPipe } from './_pipes/_index'

//project components
import { AppComponent } from './app.component';
import { LoginComponent } from './acc_management/login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminLandingComponent } from './admin/admin-landing/admin-landing.component';
import { GlobalErrorHandler } from './_handlers/error.handler';
import { LibraryComponent } from './admin/library/library.component';
import { UploadVideoComponent } from './uploadfile/upload-video/upload-video.component';
import { RegisterComponent } from './acc_management/register/register.component';
import { SearchComponent } from './search/search.component';
import { ForgotPasswordComponent } from './acc_management/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './acc_management/change-password/change-password.component';
import { VideoplayerComponent } from './videoplayer/videoplayer.component';
import { ViewComponent } from './view/view.component';
import { HistoryComponent } from './history/history.component';
import { AddvideosComponent } from './addvideos/addvideos.component';
import { LinkusercollectionvideoComponent } from './linkusercollectionvideo/linkusercollectionvideo.component';
import { RelatedvideoComponent } from './relatedvideo/relatedvideo.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { WatchlaterComponent } from './watchlater/watchlater.component';
import { CollectionvideoComponent } from './collectionvideo/collectionvideo.component';
import { PlaylistListComponent } from './playlist/playlist-list/playlist-list.component';
import { SettingsComponent } from './settings/settings.component';
import { PlaylistdropdownComponent } from './playlist/playlist-dropdown/playlist-dropdown.component';
import { AddplaylistComponent } from './playlist/addplaylist/addplaylist.component';
import { ListVideoComponent } from './uploadfile/list-video/list-video.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { EditVideoComponent } from './uploadfile/edit-video/edit-video.component';
import { CollectionComponent } from './collections/collection/collection.component';
import { VideosfromplaylistComponent } from './videoplayer/videosfromplaylist/videosfromplaylist.component';
import { VideoCommentComponent } from './video-comment/video-comment.component';

@NgModule({
  declarations: [
    FilterPipe,
    TimeAgoPipe,
    AppComponent,
    LoginComponent,
    HomeComponent,
    AdminLandingComponent,
    LibraryComponent,
    RegisterComponent,
    EqualValidator,
    UploadVideoComponent,
    SearchComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    VideoplayerComponent,
    ViewComponent,
    HistoryComponent,
    AddvideosComponent,
    LinkusercollectionvideoComponent,
    RelatedvideoComponent,
    PlaylistComponent,
    WatchlaterComponent,
    CollectionvideoComponent,
    PlaylistListComponent,
    SettingsComponent,
    PlaylistdropdownComponent,
    AddplaylistComponent,
    ListVideoComponent,
    EditVideoComponent,
    CollectionComponent,
    VideosfromplaylistComponent,
    VideoCommentComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TagInputModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    NgxCarouselModule,
    OrderModule,
    AngularMultiSelectModule,
    Ng4LoadingSpinnerModule.forRoot()
  ],
  providers: [AuthGuard
    , AdminGuard
    , AuthService
    , LibraryService
    , FileService
    , ElasticService
    , NotificationService
    , CollectionService
    , DataService
    , HistoryService
    , PlaylistService
    , WatchLaterService
    , SettingsService
    , CommentService
    , { provide: ErrorHandler, useClass: GlobalErrorHandler }]
  , bootstrap: [AppComponent]
})
export class AppModule { }
