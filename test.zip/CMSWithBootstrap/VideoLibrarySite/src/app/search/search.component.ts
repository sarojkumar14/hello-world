import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ElasticService } from '../_services/elastic.service';
import { AuthService, DataService, NotificationService } from '../_services';
import { ElasticConfig } from '../_helpers/index';
import { ElasticModel } from '../_models';
import * as _ from "lodash";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  private page: number = 1;
  private pageSize: number = 10;
  private token: string = '';
  private elasticSearchResponse: any = [];
  private filterableCollection: any = [];
  private datalength = 0;
  private searchTerm: string = '_source.FileName';
  private order: string = '';
  private reverse: boolean = false;
  private uniqueTopic: any;
  private uniqueUnit: any;
  private uniqueGrade: any;
  private filterProperties = [];
  private filterArr = [];

  constructor(private activatedRoute: ActivatedRoute
    , private route: Router
    , private elasticService: ElasticService
    , private authService: AuthService
    , private notification: NotificationService
    , private dataService: DataService) {
    this.token = this.authService.getCurrentUserAccessToken();

    // this.dataService.createEvent.subscribe(item => alert(item));

    this.activatedRoute.params.subscribe(param => {
      let search = new ElasticModel();
      search.index = ElasticConfig.INDEX;
      search.docType = ElasticConfig.TYPE;

      /* filter based on the user subscription collection, for Future use DONT DELETE.
      "query": {
              "bool": {
                  "must": {
                      "multi_match": {
                          "query": "tag3",
                          "fields": ["Tags", "FileName","attachment.content" ]
                      }
                  },
                  "filter": {
                      "terms": {
                          "Collection":["collectionone","collectiontwo"]
                      }
                  }
              }
          }
      */

      search.payload = `{
          "query":{
            "multi_match":{
              "query":"${param.searchTerm}",
               "type":"most_fields",
               "fields": [ "Tags","Title","FileName","attachment.content" ]
            }
          }
      }`

      this.elasticService.search(search, this.token)
        .subscribe(response => {

          this.uniqueTopic = _.map(_.uniqBy(response, '_source.Topic'), function (item) {
            return {
              checked: false,
              value: item._source.Topic
            };
          });

          this.uniqueUnit = _.map(_.uniqBy(response, '_source.Unit'), function (item) {
            return {
              checked: false,
              value: item._source.Unit
            };
          });

          this.uniqueGrade = _.map(_.uniqBy(response, '_source.Grade'), function (item) {
            return {
              checked: false,
              value: item._source.Grade
            };
          });
          
          console.log(this.uniqueTopic)
          console.log(this.uniqueUnit)
          console.log(this.uniqueGrade)
          this.elasticSearchResponse = response;
          this.filterableCollection = response;
        },
          err => {
            this.notification.showError("An error occured while search");
          })
    })
  }

  filter(property, item) {
    this.filterProperties.push({ "Property": property, "FilterBy": item });


    console.log(this.filterProperties)
  }

  orderBy(option) {
    if (this.order == option) {
      this.reverse = !this.reverse;
    }
    this.order = option;
  }
  changePaging(page) {
    this.pageSize = page;
  }

  filterCollection(option) {
    this.filterableCollection = this.elasticSearchResponse.filter(function (node) {
      if (option == "video") {
        return node._source.Type == "video/mp4";
      } else if (option == "document") {
        console.log(node._source)
        return node._source.Type != "video/mp4";
      } else {
        return node;
      }
    })
  }

  updateFilter(property, appt) {
    if (!appt.checked) {
      this.filterArr.push({ "property": property, "value": appt.value })
    }
    else {
      let index = this.filterArr.map(function (e) { return e.value }).indexOf(appt.value)
      this.filterArr.splice(index, 1)
    }
  }

  ngOnInit() {

  }

}
