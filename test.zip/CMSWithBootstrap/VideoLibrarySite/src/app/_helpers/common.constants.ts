export class CommonConstants {
    public static get API_URL(): string { return "http://localhost:3000/" }
}