export enum SettingsKeyConstants {
    ElasticHost,
    ElasticIndex,
    MailHost,
    MailPassword,
    MailPort,
    MailUsername,
    MailSecure,
    ElasticSearchSize,
    ElasticType
}