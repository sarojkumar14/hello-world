export class ElasticConfig {
    public static get INDEX(): string { return "videolib" };
    public static get TYPE(): string { return "videoresource" };
}