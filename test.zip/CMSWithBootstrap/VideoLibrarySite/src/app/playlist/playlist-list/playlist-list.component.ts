import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import * as $ from 'jquery';
import { ActivatedRoute } from "@angular/router";
import { CollectionService, PlaylistService, AuthService, NotificationService } from '../../_services/index'
import { PlaylistModel } from '../../_models/playlist';
import "rxjs/add/operator/takeWhile";

@Component({
  selector: 'app-playlist-list',
  templateUrl: './playlist-list.component.html',
  styleUrls: ['./playlist-list.component.css']
})
export class PlaylistListComponent implements OnInit {
  currentUser: any;
  currentUserData: any;
  responseData: any;
  playlistArray: any;
  private alive: boolean = true;
  videoId: any;
  playlist: PlaylistModel;
  filteredPlaylist: any;
  playlistId: Number = 0;
  selectedIndex: Number = 0;
  unsubscriberApi;

  constructor(private _playlistService: PlaylistService, private _authService: AuthService, private _collectinService: CollectionService,
    private _notificationService: NotificationService, private activatedRoute: ActivatedRoute) {

    //this.activatedRoute.params.subscribe(params => console.log(params));
    const url: string = activatedRoute.snapshot.url.join('');

    this.videoId = null;
    _playlistService.apiCreateData$
      .takeWhile(() => this.alive)
      .subscribe((result) => {
        this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
        this.currentUserData = this.currentUser.Data;
        this.getPlaylistByUser();
      })

    this.unsubscriberApi = _collectinService.apiData$
      .takeWhile(() => this.alive)
      .subscribe((result) => {
        this.videoId = result;
        console.log(this.videoId)
      });



  }

  ngOnInit() {
    this.playlist = new PlaylistModel();
  }

  ngOnDestroy() {
    this.alive = false;
  }

  getPlaylistByUser() {
    let playlist = {
      UserId: this.currentUserData.UserId,
      token: this.currentUser.token
    }
    this._playlistService.getPlaylistByUser(playlist).subscribe((result) => {
      this.responseData = result;
      this.playlistArray = this.responseData.data;
      this.filteredPlaylist = Object.assign([], this.playlistArray);
      if (this.playlistArray.length != 0) {
        this._playlistService.setPlaylistCounter(this.playlistArray[0].PlaylistId)
      } else {
        this._playlistService.setPlaylistCounter(0)
      }
    })
  }

  filterPlaylist(value) {
    if (!value) {
      this.filteredPlaylist = Object.assign([], this.playlistArray);
    } //when nothing has typed
    this.filteredPlaylist = Object.assign([], this.playlistArray).filter(
      item => item.Title.toLowerCase().indexOf(value.toLowerCase()) > -1
    )
  }


  selectPlaylistVideo(playlist, index) {
    console.log(playlist)
    this.selectedIndex = index;
    if (this.videoId != null) {
      let playlistObj = {
        token: this.currentUser.token,
        playlistTitle: playlist.Title,
        VideoId: this.videoId,
        PlaylistId: playlist.PlaylistId,
        CreatedOn: new Date(Date.now()).toISOString(),
        CreatedBy: this.currentUserData.UserId
      }
      this._playlistService.addVideoToPlaylist(playlistObj).subscribe((result) => {
        console.log(result);

        this.responseData = result;
        if (this.responseData.success) {
          this._notificationService.showSuccess(this.responseData.message);
          $("#playlistModal").hide();
          $(".modal-backdrop").remove();
        }
        else {
          this._notificationService.showError(this.responseData.message);
        }

      });
    } else {
      console.log(playlist)
      this._playlistService.setPlaylistCounter(playlist.PlaylistId)
    }
  }

  removePlaylist(item) {

    let deletePlaylist = confirm("Are you sure want to delete this playlist?")
    if (deletePlaylist) {
      this._playlistService.removePlaylist(item.PlaylistId, this.currentUser.token).subscribe((response) => {
        console.log(response)
        this._playlistService.createPlaylistApi(response);
        this.selectedIndex = -1;
      })
    }
  }
  editPlaylist(playlist) {
    this.playlist.Title = playlist.Title;
    this.playlist.Description = playlist.Description;
    this.playlist.PlaylistId = playlist.PlaylistId;
  }

  updatePlaylist(value, valid) {
    this.playlist.token = this.currentUser.token;
    this.playlist.UserId = this.currentUserData.UserId;
    this.playlist.CreatedBy = this.playlist.UserId;
    this.playlist.CreatedOn = new Date(Date.now()).toISOString();

    this._playlistService.updatePlaylist(this.playlist).subscribe((result) => {

      this.responseData = result;
      console.log(this.responseData);
      let success = this.responseData[0];
      success == 1 ? this._notificationService.showSuccess("Updated successfully!") : this._notificationService.showError("Update failed!")
      if (success == 1) {
        $("#editPlaylistModal").hide();
        $(".modal-backdrop").remove();
        $("#editPlaylistModal").css("display", "none");
        this.getPlaylistByUser();
        //this._playlistService.createPlaylistApi(this.responseData.data);

      }
    })
  }
}
