import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { PlaylistModel } from '../../_models/index'


@Component({
  selector: 'app-playlistdropdown',
  templateUrl: './playlist-dropdown.component.html',
  styleUrls: ['./playlist-dropdown.component.css']
})
export class PlaylistdropdownComponent implements OnInit {

  constructor() { }

  playlist: PlaylistModel;

  @Output() selectVideoToPlaylist = new EventEmitter<Number>();
  @Output() addVideoToPlaylist = new EventEmitter<Number>();

  ngOnInit() {

  }

  linkVideoToPlaylist(videoId: Number) {
    this.selectVideoToPlaylist.emit(videoId);
  }

  add(data: any) {
    this.addVideoToPlaylist.emit(data);
  }

  update() {

  }
}
