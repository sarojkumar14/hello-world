import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistdropdownComponent } from './playlist-dropdown.component';

describe('PlaylistdropdownComponent', () => {
  let component: PlaylistdropdownComponent;
  let fixture: ComponentFixture<PlaylistdropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PlaylistdropdownComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistdropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
