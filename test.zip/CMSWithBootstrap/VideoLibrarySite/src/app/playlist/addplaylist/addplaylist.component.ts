import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery'
import { PlaylistModel } from '../../_models/index'
import { CollectionService, PlaylistService, AuthService, NotificationService } from '../../_services/index'

@Component({
  selector: 'app-addplaylist',
  templateUrl: './addplaylist.component.html',
  styleUrls: ['./addplaylist.component.css']
})
export class AddplaylistComponent implements OnInit {
  alive: boolean = true;
  videoId: Number = 0;
  constructor(private _authService: AuthService,
    private _playlistService: PlaylistService,
    private _notificationService: NotificationService) {
    _playlistService.apiCreateData$
      .takeWhile(() => this.alive)
      .subscribe((result) => {
        this.videoId = result;
        console.log(this.videoId);
      });
  }
  playlist: any;
  currentUser: any;
  currentUserData: any;
  responseData: any;
  ngOnInit() {
    this.playlist = new PlaylistModel();
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    this.currentUserData = this.currentUser.Data;
  }

  ngOnDestroy() {
    this.alive = false;
  }
  update(value, valid) {
    console.log(valid)
    console.log(value)
  }

  savePlaylist(value, valid) {
    this.playlist.token = this.currentUser.token;
    this.playlist.UserId = this.currentUserData.UserId;
    this.playlist.CreatedBy = this.playlist.UserId;
    this.playlist.CreatedOn = new Date(Date.now()).toISOString();
    this.playlist.VideoId = this.videoId;
    this._playlistService.createPlaylist(this.playlist).subscribe((result) => {

      this.responseData = result;

      let success = this.responseData.success;
      let message = this.responseData.message;
      success ? this._notificationService.showSuccess(message) : this._notificationService.showError(message)
      if (success) {
        $("#addVideoPlaylistModal").removeClass("show");
        $(".modal-backdrop").remove();
        $("#addVideoPlaylistModal").css("display", "none");
        this._playlistService.setPlaylistCounter(this.responseData.data)
        this._playlistService.playlistCountByUser(this.playlist).subscribe((result) => {
          console.log(result);
          this.responseData = result;
          this._playlistService.createPlaylistApi(result)
        })

      }
    })
  }
}
