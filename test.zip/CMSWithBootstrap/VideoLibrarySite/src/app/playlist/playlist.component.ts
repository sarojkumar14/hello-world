import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { PlaylistService, AuthService, NotificationService } from '../_services/index'
import { PlaylistModel } from '../_models/playlist';
import "rxjs/add/operator/takeWhile";

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css']
})

export class PlaylistComponent implements OnInit {

  playlist: PlaylistModel;
  currentUser: any;
  currentUserData: any;
  responseData: any;
  playlistArray: any;
  playlistCounter: Number;
  searchPlaylist: String;
  filterableCollection: any;
  playlistId: Number;
  private alive: boolean = true;

  constructor(private _playlistService: PlaylistService, private _authService: AuthService,
    private _notificationService: NotificationService) {
    this.currentUser = JSON.parse(this._authService.getAuthUserDetail());
    this.currentUserData = this.currentUser.Data;


  }
  removeVideoFromPlaylist(event) {
    console.log(event)
    this._playlistService.removeVideoFromPlaylist(event.value, this.currentUser.token).subscribe(result => {
      //this.getPlaylistVideo(this.playlistId);
      this._playlistService.createPlaylistApi(event);
    })
  }

  getPlaylistVideo(data) {
    this._playlistService.getPlaylistVideo(data, this.currentUser.token).subscribe(result => {
      this.responseData = result;
      this.filterableCollection = this.responseData.data;
    })
  }

  ngOnInit() {

    this.playlist = new PlaylistModel();
    this.playlist.token = this.currentUser.token;
    this.playlist.UserId = this.currentUserData.UserId;

    this._playlistService.apiData$
      .takeWhile(() => this.alive)
      .subscribe((data) => {
        console.log(data);
        this.filterableCollection = [];
        if (data != null) {
          console.log(data)
          this.playlistId = data;
          this.getPlaylistVideo(data);
        }
      });
    //this.getPlaylistByUser();
  }

  ngOnDestroy() {
    this.alive = false;
  }


  getPlaylistByUser() {
    this._playlistService.playlistCountByUser(this.playlist).subscribe((result) => {
      this.responseData = result;
      this.playlistCounter = this.responseData.data;
    })
  }

  filterPlaylist(value) {
    console.log(value);
    this._playlistService.filterPlaylist(value);
  }


  createPlaylist(value, valid) {
    this.playlist.token = this.currentUser.token;
    this.playlist.UserId = this.currentUserData.UserId;
    this.playlist.CreatedBy = this.playlist.UserId;
    this.playlist.CreatedOn = new Date(Date.now()).toISOString();

    this._playlistService.createPlaylist(this.playlist).subscribe((result) => {

      this.responseData = result;

      let success = this.responseData.success;
      let message = this.responseData.message;
      success ? this._notificationService.showSuccess(message) : this._notificationService.showError(message)
      if (success) {
        $("#createPlaylistModal").removeClass("show");
        $(".modal-backdrop").remove();
        $("#createPlaylistModal").css("display", "none");
        this._playlistService.setPlaylistCounter(this.responseData.data)
        this._playlistService.playlistCountByUser(this.playlist).subscribe((result) => {
          console.log(result);
          this.responseData = result;
          this._playlistService.createPlaylistApi(result)
        })

      }
    })
  }
}
